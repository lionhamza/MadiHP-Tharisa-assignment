# raw/
This is a folder where the raw excel data is aploaded.

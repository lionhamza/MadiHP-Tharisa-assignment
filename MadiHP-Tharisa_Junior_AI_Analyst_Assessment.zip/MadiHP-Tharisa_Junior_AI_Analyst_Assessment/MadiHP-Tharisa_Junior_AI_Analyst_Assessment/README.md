# MadiHP_Junior_AI_Analyst_Assessment — Submission Workspace

## Folder guide

- `raw/` — the original source data. This is left untouched.
- `cleaned/` — cleaned datasets and the final exception report.
- `scripts/` — all cleaning, validation and reconciliation code.
- `reports/` — written deliverables, including the data-quality report,
  executive summary, testing evidence and responsible-use documentation.
- `app/` — Task 2 and Task 3 solutions.

## How to run

Run the scripts from the `scripts/` folder. Make sure
`raw/source_data.xlsx` is in place first.

```bash
python3 cleaning_equipment_events.py
python3 cleaning_delays_downtime.py
python3 cleaning_maintenance_notifications.py
python3 cleaning_operator_activities.py
python3 cleaning_safety_observations.py
python3 cleaning_shift_performance.py
python3 clean_training_records.py
python3 clean_access_control.py
python3 clean_environmental_readings.py
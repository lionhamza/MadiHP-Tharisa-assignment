"""
clean_safety_observations.py

Cleans and validates the Safety_Observations sheet.

The main checks in this pipeline are:

- Remove exact duplicate rows
- Standardise equipment names and dates
- Fix known category and severity inconsistencies
- Check for logical problems between observation dates, closed dates,
  and status
- Flag contradictions between severity and description
- Remove sensitive or unsupported information from free-text fields
- Create an exceptions file for records that need review
- Save a changelog showing what was changed or flagged

The script avoids guessing. Where a problem cannot be corrected with
confidence, the record is flagged instead.
"""

import pandas as pd

from utils import canonicalize_equipment_names, parse_dates


RAW_PATH = "../raw/source_data.xlsx"
OUT_PATH = "../cleaned/safety_observations_cleaned.csv"
EXCEPTIONS_PATH = "../cleaned/safety_observations_exceptions.csv"
CHANGELOG_PATH = "../reports/safety_observations_changelog.csv"


# Known typo found in the Category column
CATEGORY_CORRECTIONS = {
    "saftey": "Safety"
}


# SAF0027 contains a named person in the description together with
# an unsupported claim. The description is redacted in the cleaned output.
FLAGGED_CONTENT_IDS = ["SAF0027"]


def drop_exact_duplicates(df, log):
    """Remove rows that are completely identical."""

    before = len(df)

    df = df.drop_duplicates(keep="first").copy()

    removed = before - len(df)

    if removed > 0:
        log.append({
            "step": "duplicates",
            "action": "Removed exact duplicate rows",
            "rows_affected": int(removed)
        })

    return df


def fix_category(df, log):
    """Standardise category values and fix known typos."""

    df = df.copy()

    original = df["Category"].astype("string").copy()

    cleaned = (
        original
        .str.strip()
        .str.lower()
        .replace(CATEGORY_CORRECTIONS)
    )

    df["Category_Clean"] = cleaned.str.title()

    changed = (original != df["Category_Clean"]).sum()

    log.append({
        "step": "category",
        "action": "Standardised category values and corrected 'Saftey' to 'Safety'",
        "rows_affected": int(changed)
    })

    return df


def fix_severity(df, log):
    """Standardise severity values."""

    df = df.copy()

    original = df["Severity"].astype("string").copy()

    df["Severity_Clean"] = (
        original
        .str.strip()
        .str.title()
    )

    changed = (
        original != df["Severity_Clean"]
    ).sum()

    log.append({
        "step": "severity",
        "action": "Standardised severity formatting",
        "rows_affected": int(changed)
    })

    return df


def check_date_logic(df, log):
    """
    Check whether the observation date, closed date, and status
    make sense together.
    """

    df = df.copy()

    # A record cannot be closed before it was observed
    df["Closed_Before_Observed"] = (
        df["Closed_Date_Clean"].notna()
        &
        (
            df["Closed_Date_Clean"]
            <
            df["Observation_Date_Clean"]
        )
    )

    # An open observation should not have a closed date
    df["Open_With_Closed_Date"] = (
        df["Status"] == "Open"
    ) & df["Closed_Date"].notna()

    # A closed observation should have a closed date
    df["Closed_Missing_Closed_Date"] = (
        df["Status"] == "Closed"
    ) & df["Closed_Date"].isna()

    closed_before = df["Closed_Before_Observed"].sum()

    open_with_date = (
        df["Open_With_Closed_Date"]
        .sum()
    )

    closed_without_date = (
        df["Closed_Missing_Closed_Date"]
        .sum()
    )

    log.append({
        "step": "date_logic",
        "action": "Flagged records where Closed_Date is before Observation_Date",
        "rows_affected": int(closed_before)
    })

    log.append({
        "step": "date_logic",
        "action": "Flagged open records that still have a Closed_Date",
        "rows_affected": int(open_with_date)
    })

    log.append({
        "step": "date_logic",
        "action": "Flagged closed records with no Closed_Date",
        "rows_affected": int(closed_without_date)
    })

    return df


def check_severity_description(df, log):
    """
    Flag records where the severity does not appear to match
    the description.

    These records are not automatically corrected because it is not
    possible to know whether the severity or description is incorrect.
    """

    df = df.copy()

    positive_descriptions = [
        "good housekeeping noted"
    ]

    description_is_positive = (
        df["Description"]
        .astype("string")
        .str.strip()
        .str.lower()
        .isin(positive_descriptions)
    )

    df["Severity_Description_Contradiction"] = (
        df["Severity_Clean"] == "Critical"
    ) & description_is_positive

    count = (
        df["Severity_Description_Contradiction"]
        .sum()
    )

    log.append({
        "step": "severity_description",
        "action": (
            "Flagged records where a Critical severity does not match "
            "the description"
        ),
        "rows_affected": int(count)
    })

    return df


def redact_sensitive_content(df, log):
    """
    Remove descriptions that contain a directly identified person together
    with an unsupported allegation.

    The original value remains in the raw dataset. Only the cleaned
    analysis output contains the redacted version.
    """

    df = df.copy()

    df["Description_Clean"] = df["Description"]

    df["Contains_Flagged_Content"] = (
        df["Observation_ID"]
        .isin(FLAGGED_CONTENT_IDS)
    )

    df.loc[
        df["Contains_Flagged_Content"],
        "Description_Clean"
    ] = "[REDACTED - contains identified individual and unsupported claim]"

    count = (
        df["Contains_Flagged_Content"]
        .sum()
    )

    log.append({
        "step": "content_review",
        "action": (
            "Redacted descriptions containing an identified person "
            "and an unsupported claim from the cleaned output"
        ),
        "rows_affected": int(count)
    })

    return df


def build_exceptions(df):
    """
    Create a table containing all records that still need review.
    """

    reasons = []

    for _, row in df.iterrows():

        row_reasons = []

        if pd.isna(
            row.get("Equipment_Name_Clean")
        ):
            row_reasons.append(
                "Unresolved equipment name"
            )

        if pd.isna(
            row.get("Observation_Date_Clean")
        ):
            row_reasons.append(
                "Unparseable observation date"
            )

        if row.get(
            "Closed_Before_Observed"
        ):
            row_reasons.append(
                "Closed_Date is before Observation_Date"
            )

        if row.get(
            "Open_With_Closed_Date"
        ):
            row_reasons.append(
                "Status is Open but a Closed_Date is present"
            )

        if row.get(
            "Closed_Missing_Closed_Date"
        ):
            row_reasons.append(
                "Status is Closed but Closed_Date is missing"
            )

        if row.get(
            "Severity_Description_Contradiction"
        ):
            row_reasons.append(
                "Severity does not appear to match the description"
            )

        if row.get(
            "Contains_Flagged_Content"
        ):
            row_reasons.append(
                "Description was redacted due to sensitive or unsupported content"
            )

        if row_reasons:
            reasons.append(
                "; ".join(row_reasons)
            )
        else:
            reasons.append(None)

    df = df.copy()

    df["exception_reason"] = reasons

    return df[
        df["exception_reason"].notna()
    ].copy()


def run_pipeline():

    log = []

    # Load the Safety_Observations sheet
    df = pd.read_excel(
        RAW_PATH,
        sheet_name="Safety_Observations"
    )

    print(
        f"Loaded {len(df)} raw rows"
    )

    # Run cleaning steps
    df = drop_exact_duplicates(
        df,
        log
    )

    df = canonicalize_equipment_names(
        df,
        log
    )

    df = parse_dates(
        df,
        log,
        column="Observation_Date"
    )

    df = parse_dates(
        df,
        log,
        column="Closed_Date"
    )

    df = fix_category(
        df,
        log
    )

    df = fix_severity(
        df,
        log
    )

    df = check_date_logic(
        df,
        log
    )

    df = check_severity_description(
        df,
        log
    )

    df = redact_sensitive_content(
        df,
        log
    )

    # Build the exceptions table
    exceptions_df = build_exceptions(df)

    # Replace the original Description with the cleaned version
    df_to_save = (
        df
        .drop(columns=["Description"])
        .rename(
            columns={
                "Description_Clean": "Description"
            }
        )
    )

    # Save outputs
    df_to_save.to_csv(
        OUT_PATH,
        index=False
    )

    exceptions_df.to_csv(
        EXCEPTIONS_PATH,
        index=False
    )

    pd.DataFrame(log).to_csv(
        CHANGELOG_PATH,
        index=False
    )

    # Print summary
    print(
        f"\nFinal row count: {len(df)}"
    )

    print(
        f"Rows with at least one exception: "
        f"{len(exceptions_df)}"
    )

    print(
        f"\nChange log ({len(log)} entries):"
    )

    for entry in log:

        print(
            f"  [{entry['step']}] "
            f"{entry['action']} - "
            f"{entry['rows_affected']} rows"
        )

    print("\nSaved files:")

    print(f"  {OUT_PATH}")
    print(f"  {EXCEPTIONS_PATH}")
    print(f"  {CHANGELOG_PATH}")

    if not exceptions_df.empty:

        print("\nException summary:")

        print(
            exceptions_df[
                [
                    "Observation_ID",
                    "exception_reason"
                ]
            ].to_string(
                index=False
            )
        )

    return df, exceptions_df, log


if __name__ == "__main__":
    run_pipeline()
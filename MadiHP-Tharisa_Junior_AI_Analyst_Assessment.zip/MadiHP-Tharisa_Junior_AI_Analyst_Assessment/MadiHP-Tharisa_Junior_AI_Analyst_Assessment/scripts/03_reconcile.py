"""
03_reconcile.py

This script checks for problems between different cleaned datasets.

The individual cleaning scripts check each dataset on its own. This script
does extra checks where the problem can only be found by comparing one
dataset with another.

It checks:

1. Equipment names across datasets against the main equipment list.
2. Employee IDs in Access_Control against Training_Records.
3. Overlapping activities for the same operator.
4. Combines all exception files into one exception report.
"""

import pandas as pd
from pathlib import Path


CLEANED_DIR = Path("../cleaned")


# Exception files created by the cleaning scripts
EXCEPTION_FILES = {
    "Equipment_Events": "equipment_events_exceptions.csv",
    "Delays_Downtime": "delays_downtime_exceptions.csv",
    "Operator_Activities": "operator_activities_exceptions.csv",
    "Shift_Performance": "shift_performance_exceptions.csv",
    "Safety_Observations": "safety_observations_exceptions.csv",
    "Training_Records": "training_records_exceptions.csv",
    "Maintenance_Notifications": "maintenance_notifications_exceptions.csv",
    "Environmental_Readings": "environmental_readings_exceptions.csv",
    "Access_Control": "access_control_exceptions.csv",
}


# The main ID column used in each dataset
ID_COLUMNS = {
    "Equipment_Events": "Event_ID",
    "Delays_Downtime": "Delay_ID",
    "Operator_Activities": "Activity_ID",
    "Shift_Performance": "Shift_Record_ID",
    "Safety_Observations": "Observation_ID",
    "Training_Records": "Training_Record_ID",
    "Maintenance_Notifications": "Notification_ID",
    "Environmental_Readings": "Reading_ID",
    "Access_Control": "Access_Event_ID",
}


# ------------------------------------------------------------
# Build one combined exception report
# ------------------------------------------------------------

def build_exception_report():

    all_exceptions = []

    for dataset, filename in EXCEPTION_FILES.items():

        file_path = CLEANED_DIR / filename

        if not file_path.exists():
            print(f"Warning: {filename} was not found.")
            continue

        df = pd.read_csv(file_path)

        id_column = ID_COLUMNS[dataset]

        for _, row in df.iterrows():

            record_id = row.get(id_column)

            # Some files may use a slightly different version of the ID name
            if pd.isna(record_id):
                alternative_id = id_column.replace("_ID", "ID")
                record_id = row.get(alternative_id)

            all_exceptions.append({
                "Dataset": dataset,
                "Record_ID": record_id,
                "Exception_Reason": row.get("exception_reason")
            })

    exception_report = pd.DataFrame(all_exceptions)

    output_path = CLEANED_DIR / "exception_report.csv"

    exception_report.to_csv(
        output_path,
        index=False
    )

    print(
        f"\nCombined exception report created: "
        f"{len(exception_report)} records"
    )

    print(f"Saved to: {output_path}\n")

    if not exception_report.empty:
        print("Exceptions by dataset:")
        print(exception_report["Dataset"].value_counts())

    return exception_report


# ------------------------------------------------------------
# Equipment check across datasets
# ------------------------------------------------------------

def check_equipment():

    # Equipment_Events is used as the master equipment list
    equipment_file = CLEANED_DIR / "equipment_events_cleaned.csv"

    equipment_df = pd.read_csv(equipment_file)

    master_equipment = set(
        equipment_df["Equipment_Name_Clean"]
        .dropna()
        .unique()
    )


    datasets_to_check = [
        (
            "Delays_Downtime",
            "delays_downtime_cleaned.csv",
            "Equipment_Name_Clean"
        ),
        (
            "Maintenance_Notifications",
            "maintenance_notifications_cleaned.csv",
            "Equipment_Name_Clean"
        ),
        (
            "Operator_Activities",
            "operator_activities_cleaned.csv",
            "Equipment_Name_Clean"
        ),
        (
            "Safety_Observations",
            "safety_observations_cleaned.csv",
            "Equipment_Name_Clean"
        ),
        (
            "Environmental_Readings",
            "environmental_readings_cleaned.csv",
            "Equipment_Nearby_Clean"
        )
    ]


    findings = []

    for dataset, filename, column in datasets_to_check:

        df = pd.read_csv(
            CLEANED_DIR / filename
        )

        equipment_values = set(
            df[column]
            .dropna()
            .unique()
        )

        # Find equipment values that are not in the master list
        missing_equipment = (
            equipment_values - master_equipment
        )

        if missing_equipment:

            findings.append(
                f"{dataset}: equipment not found in the "
                f"master list: {missing_equipment}"
            )


    if not findings:

        findings.append(
            "PASSED: All equipment values checked across the "
            "datasets match the equipment master list."
        )

    return findings


# ------------------------------------------------------------
# Identity check between Access_Control and Training_Records
# ------------------------------------------------------------

def check_operator_identity():

    training = pd.read_csv(
        CLEANED_DIR / "training_records_cleaned.csv"
    )

    access = pd.read_csv(
        CLEANED_DIR / "access_control_cleaned.csv"
    )


    # Get all known operators from Training_Records
    training_operators = set(
        training["Operator_ID"]
        .dropna()
        .unique()
    )


    # Get all employee IDs from Access_Control
    access_operators = set(
        access["Employee_ID"]
        .dropna()
        .unique()
    )


    # Find IDs that appear in Access_Control but not in Training_Records
    missing_operators = (
        access_operators - training_operators
    )


    findings = []

    if missing_operators:

        findings.append(
            "Access_Control contains the following Employee_ID values "
            "that do not appear in Training_Records: "
            f"{missing_operators}"
        )

        findings.append(
            "This supports the issue already found in Access_Control. "
            "OP9999 was flagged because it does not match the expected "
            "operator linked to the badge information. The missing match "
            "in Training_Records provides another reason to treat the "
            "ID as suspicious, but it is still not automatically corrected."
        )

    else:

        findings.append(
            "PASSED: Every Employee_ID in Access_Control has a matching "
            "Operator_ID in Training_Records."
        )


    return findings


# ------------------------------------------------------------
# Check for overlapping operator activities
# ------------------------------------------------------------

def check_activity_overlaps():

    activity_file = (
        CLEANED_DIR / "operator_activities_cleaned.csv"
    )

    activities = pd.read_csv(
        activity_file,
        parse_dates=[
            "Activity_Start_Clean",
            "Activity_End_Clean"
        ]
    )


    # Ignore incomplete records for this check
    activities = activities.dropna(
        subset=[
            "Operator_ID",
            "Activity_Start_Clean",
            "Activity_End_Clean"
        ]
    )


    overlaps = []


    # Check activities for each operator
    for operator_id, group in activities.groupby("Operator_ID"):

        group = group.sort_values(
            "Activity_Start_Clean"
        )

        previous_end = None
        previous_activity = None


        for _, row in group.iterrows():

            current_start = row["Activity_Start_Clean"]
            current_end = row["Activity_End_Clean"]
            current_activity = row["Activity_ID"]


            # If the current activity starts before the previous one ends,
            # the two activities overlap.
            if previous_end is not None:

                if current_start < previous_end:

                    overlaps.append(
                        f"{operator_id}: "
                        f"{previous_activity} overlaps with "
                        f"{current_activity}"
                    )


            previous_end = current_end
            previous_activity = current_activity


    if not overlaps:

        return [
            "PASSED: No overlapping activity times were found "
            "for the same operator."
        ]

    return overlaps


# ------------------------------------------------------------
# Run all reconciliation checks
# ------------------------------------------------------------

def run():

    print("\n=== Cross-Dataset Reconciliation ===\n")


    # Equipment check
    print("1. Equipment cross-check:")

    equipment_results = check_equipment()

    for result in equipment_results:
        print(f"   {result}")


    # Identity check
    print("\n2. Operator identity cross-check:")

    identity_results = check_operator_identity()

    for result in identity_results:
        print(f"   {result}")


    # Activity overlap check
    print("\n3. Activity overlap check:")

    overlap_results = check_activity_overlaps()

    for result in overlap_results:
        print(f"   {result}")


    # Build combined exception report
    print("\n4. Building combined exception report...")

    build_exception_report()


if __name__ == "__main__":
    run()
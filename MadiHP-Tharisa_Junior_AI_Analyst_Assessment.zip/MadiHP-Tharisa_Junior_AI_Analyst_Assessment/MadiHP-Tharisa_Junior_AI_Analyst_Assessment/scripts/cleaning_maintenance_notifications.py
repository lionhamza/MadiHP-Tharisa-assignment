"""
clean_maintenance_notifications.py

Cleans and validates the Maintenance_Notifications sheet.

Main checks:
- Remove exact duplicate rows
- Standardise equipment names
- Parse mixed date formats
- Standardise notification types
- Flag priorities that do not fit the P1/P2/P3 scale
- Recalculate downtime using Actual_Start and Actual_End
- Flag incorrect or negative downtime values
- Create an exceptions file and change log
"""

import pandas as pd

from utils import canonicalize_equipment_names, parse_dates


RAW_PATH = "../raw/source_data.xlsx"
OUT_PATH = "../cleaned/maintenance_notifications_cleaned.csv"
EXCEPTIONS_PATH = "../cleaned/maintenance_notifications_exceptions.csv"
CHANGELOG_PATH = "../reports/maintenance_notifications_changelog.csv"


# Known notification type variations
NOTIFICATION_TYPE_MAP = {
    "break down": "Breakdown",
    "breakdown": "Breakdown",
    "planned": "Planned",
    "inspection": "Inspection"
}


def remove_duplicates(df, log):
    """Remove rows that are completely identical."""

    before = len(df)

    df = df.drop_duplicates(
        keep="first"
    ).copy()

    removed = before - len(df)

    if removed > 0:
        log.append({
            "step": "duplicates",
            "action": "Removed exact duplicate rows",
            "rows_affected": int(removed)
        })

    return df


def clean_notification_type(df, log):
    """
    Standardise notification types.

    'break down' and 'Breakdown' refer to the same type,
    so they are converted to one consistent value.
    """

    df = df.copy()

    original = df["Notification_Type"].astype("string")

    normalised = (
        original
        .str.strip()
        .str.lower()
    )

    df["Notification_Type_Clean"] = normalised.map(
        NOTIFICATION_TYPE_MAP
    )

    changed = (
        original != df["Notification_Type_Clean"]
    ).sum()

    log.append({
        "step": "notification_type",
        "action": (
            "Standardised notification type values, "
            "including 'break down' to 'Breakdown'"
        ),
        "rows_affected": int(changed)
    })

    return df


def check_priority_scale(df, log):
    """
    Flag priorities that do not follow the P1/P2/P3 scale.

    'Urgent' is kept as it appears in the source data rather
    than being automatically mapped to one of the P levels.
    """

    df = df.copy()

    df["Priority_Inconsistent_Scale"] = (
        df["Priority"]
        .astype(str)
        .str.strip()
        .eq("Urgent")
    )

    flagged = df[
        "Priority_Inconsistent_Scale"
    ].sum()

    log.append({
        "step": "priority",
        "action": (
            "Flagged 'Urgent' because it does not match "
            "the P1/P2/P3 priority scale"
        ),
        "rows_affected": int(flagged)
    })

    return df


def calculate_downtime(df, log):
    """
    Calculate downtime from Actual_Start and Actual_End.

    The calculated value is compared with the original
    Downtime_Hours value to identify negative or inconsistent
    downtime records.
    """

    df = df.copy()

    time_difference = (
        df["Actual_End_Clean"] -
        df["Actual_Start_Clean"]
    )

    df["Downtime_Hours_Calculated"] = (
        time_difference.dt.total_seconds() / 3600
    )

    provided = df["Downtime_Hours"]
    calculated = df["Downtime_Hours_Calculated"]

    df["Downtime_Mismatch"] = (
        provided.isna()
        | (provided < 0)
        | ((provided - calculated).abs() > 0.5)
    )

    negative_count = (
        provided < 0
    ).sum()

    mismatch_count = (
        (provided.notna())
        & (provided >= 0)
        & ((provided - calculated).abs() > 0.5)
    ).sum()

    log.append({
        "step": "downtime_hours",
        "action": (
            "Calculated downtime from Actual_Start "
            "and Actual_End"
        ),
        "rows_affected": len(df)
    })

    log.append({
        "step": "downtime_hours",
        "action": "Flagged negative downtime values",
        "rows_affected": int(negative_count)
    })

    log.append({
        "step": "downtime_hours",
        "action": (
            "Flagged downtime values that differ from "
            "the calculated duration by more than 0.5 hours"
        ),
        "rows_affected": int(mismatch_count)
    })

    return df


def build_exceptions(df):
    """Create a table containing rows that need review."""

    exception_reasons = []

    for _, row in df.iterrows():

        reasons = []

        if pd.isna(
            row.get("Equipment_Name_Clean")
        ):
            reasons.append(
                "Unresolved equipment name"
            )

        if (
            pd.isna(row.get("Actual_Start_Clean"))
            or pd.isna(row.get("Actual_End_Clean"))
        ):
            reasons.append(
                "Unparseable Actual_Start or Actual_End"
            )

        if row.get("Downtime_Mismatch"):
            reasons.append(
                "Downtime_Hours does not match the "
                "duration calculated from Actual_Start "
                "and Actual_End"
            )

        if row.get(
            "Priority_Inconsistent_Scale"
        ):
            reasons.append(
                "Priority 'Urgent' does not fit the "
                "P1/P2/P3 priority scale"
            )

        if reasons:
            exception_reasons.append(
                "; ".join(reasons)
            )
        else:
            exception_reasons.append(None)

    df = df.copy()

    df["exception_reason"] = exception_reasons

    return df[
        df["exception_reason"].notna()
    ].copy()


def run_pipeline():

    log = []

    # Load the Maintenance_Notifications sheet
    df = pd.read_excel(
        RAW_PATH,
        sheet_name="Maintenance_Notifications"
    )

    print(f"Loaded {len(df)} raw rows")

    # Run cleaning and validation steps
    df = remove_duplicates(df, log)

    df = canonicalize_equipment_names(
        df,
        log
    )

    df = parse_dates(
        df,
        log,
        column="Raised_Date"
    )

    df = parse_dates(
        df,
        log,
        column="Planned_Start"
    )

    df = parse_dates(
        df,
        log,
        column="Actual_Start"
    )

    df = parse_dates(
        df,
        log,
        column="Actual_End"
    )

    df = clean_notification_type(
        df,
        log
    )

    df = check_priority_scale(
        df,
        log
    )

    df = calculate_downtime(
        df,
        log
    )

    # Build exceptions table
    exceptions_df = build_exceptions(df)

    # Save cleaned data
    df.to_csv(
        OUT_PATH,
        index=False
    )

    # Save exceptions
    exceptions_df.to_csv(
        EXCEPTIONS_PATH,
        index=False
    )

    # Save change log
    pd.DataFrame(log).to_csv(
        CHANGELOG_PATH,
        index=False
    )

    # Print summary
    print(f"\nFinal row count: {len(df)}")

    print(
        f"Rows with at least one exception: "
        f"{len(exceptions_df)}"
    )

    print(
        f"\nChange log ({len(log)} entries):"
    )

    for entry in log:

        print(
            f"  [{entry['step']}] "
            f"{entry['action']} - "
            f"{entry['rows_affected']} rows"
        )

    print("\nSaved files:")

    print(f"  {OUT_PATH}")
    print(f"  {EXCEPTIONS_PATH}")
    print(f"  {CHANGELOG_PATH}")

    if not exceptions_df.empty:

        print("\nException summary:")

        columns = [
            "Notification_ID",
            "Equipment_Name",
            "Priority",
            "Downtime_Hours",
            "Downtime_Hours_Calculated",
            "exception_reason"
        ]

        print(
            exceptions_df[
                columns
            ].to_string(
                index=False
            )
        )

    return df, exceptions_df, log


if __name__ == "__main__":
    run_pipeline()
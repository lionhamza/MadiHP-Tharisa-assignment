"""
clean_access_control.py

This script cleans the Access_Control sheet and flags records that look
incorrect or need manual review.

Main checks:
- Remove exact duplicate rows
- Parse the different Event_Time formats
- Check for unusual event times
- Clean Access_Result and Direction values
- Flag missing Badge_ID values
- Check if Badge_ID and Employee_ID match
- Flag denied access records with no reason
- Mark sensitive fields
- Create cleaned data, exceptions, and a change log
"""

import re
import pandas as pd


# File locations
RAW_PATH = "../raw/source_data.xlsx"
OUT_PATH = "../cleaned/access_control_cleaned.csv"
EXCEPTIONS_PATH = "../cleaned/access_control_exceptions.csv"
CHANGELOG_PATH = "../reports/access_control_changelog.csv"


# The dataset uses a few different date/time formats
DATE_PATTERNS = [
    (
        r"^\d{2}/\d{2}/\d{4} \d{2}:\d{2}$",
        "%d/%m/%Y %H:%M",
        "DD/MM/YYYY 24hr"
    ),
    (
        r"^\d{2}/\d{2}/\d{4} \d{2}:\d{2} (AM|PM)$",
        "%m/%d/%Y %I:%M %p",
        "MM/DD/YYYY 12hr"
    ),
    (
        r"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}$",
        "%Y/%m/%d %H:%M",
        "YYYY/MM/DD 24hr"
    ),
    (
        r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$",
        "%Y-%m-%d %H:%M:%S",
        "ISO YYYY-MM-DD"
    ),
]


# Standard values for access results and directions
ACCESS_RESULT_MAP = {
    "granted": "Granted",
    "Granted": "Granted",
    "Denied": "Denied"
}

DIRECTION_MAP = {
    "IN": "IN",
    "OUT": "OUT",
    "Entry": "IN",
    "Exit": "OUT"
}


# Used when checking if an event time is far away from the normal pattern
CADENCE_TOLERANCE_HOURS = 1


def remove_duplicates(df, log):
    """Remove rows that are exactly the same."""

    original_rows = len(df)

    df = df.drop_duplicates(keep="first").copy()

    removed_rows = original_rows - len(df)

    if removed_rows > 0:
        log.append({
            "step": "duplicates",
            "action": "Removed exact duplicate rows",
            "rows_affected": removed_rows
        })

    return df


def parse_datetime(value):
    """Try to parse one Event_Time value using the known formats."""

    if pd.isna(value):
        return None, None

    value = str(value).strip()

    for pattern, date_format, format_name in DATE_PATTERNS:

        if re.match(pattern, value):
            try:
                parsed_date = pd.to_datetime(
                    value,
                    format=date_format
                )

                return parsed_date, format_name

            except ValueError:
                pass

    return None, None


def clean_event_time(df, log):
    """Parse Event_Time and save the cleaned datetime."""

    df = df.copy()

    parsed_values = df["Event_Time"].apply(parse_datetime)

    df["Event_Time_Clean"] = parsed_values.apply(
        lambda x: x[0]
    )

    df["Event_Time_Format_Detected"] = parsed_values.apply(
        lambda x: x[1]
    )

    missing_dates = df["Event_Time_Clean"].isna().sum()

    log.append({
        "step": "event_time",
        "action": "Parsed Event_Time values using the known date formats",
        "rows_affected": len(df)
    })

    if missing_dates > 0:
        log.append({
            "step": "event_time",
            "action": "Flagged Event_Time values that could not be parsed",
            "rows_affected": int(missing_dates)
        })

    # Record how many values used each date format
    format_counts = df["Event_Time_Format_Detected"].value_counts(
        dropna=True
    )

    for format_name, count in format_counts.items():

        log.append({
            "step": "event_time",
            "action": f"Parsed as {format_name}",
            "rows_affected": int(count)
        })

    return df


def check_event_time_pattern(df, log):
    """
    Check if the event times follow the normal time pattern.

    The normal gap is calculated from the data instead of being
    manually set.
    """

    df = df.copy().reset_index(drop=True)

    event_times = df["Event_Time_Clean"]

    # Calculate the gaps between events
    time_gaps = event_times.diff().dropna()

    if len(time_gaps) > 0:
        normal_gap = time_gaps.median()
    else:
        normal_gap = pd.Timedelta(0)

    # Use the first event as the starting point
    first_time = event_times.iloc[0]

    expected_times = []

    for i in range(len(df)):
        expected_time = first_time + (normal_gap * i)
        expected_times.append(expected_time)

    df["Event_Time_Expected"] = expected_times

    # Calculate the difference between actual and expected time
    difference = (
        df["Event_Time_Clean"] -
        df["Event_Time_Expected"]
    ).abs()

    difference_hours = difference.dt.total_seconds() / 3600

    df["Event_Time_Anomaly"] = (
        df["Event_Time_Clean"].notna()
        & (difference_hours > CADENCE_TOLERANCE_HOURS)
    )

    anomaly_count = df["Event_Time_Anomaly"].sum()

    log.append({
        "step": "event_time_pattern",
        "action": (
            f"Checked event times against the normal interval of "
            f"{normal_gap} and flagged large deviations"
        ),
        "rows_affected": int(anomaly_count)
    })

    return df


def clean_access_result(df, log):
    """Standardise Access_Result values."""

    df = df.copy()

    original = df["Access_Result"].copy()

    df["Access_Result_Clean"] = df[
        "Access_Result"
    ].replace(ACCESS_RESULT_MAP)

    changed = (
        original != df["Access_Result_Clean"]
    ).sum()

    if changed > 0:

        log.append({
            "step": "access_result",
            "action": "Standardised Access_Result values",
            "rows_affected": int(changed)
        })

    return df


def clean_direction(df, log):
    """Standardise Direction values to IN and OUT."""

    df = df.copy()

    original = df["Direction"].copy()

    df["Direction_Clean"] = df[
        "Direction"
    ].replace(DIRECTION_MAP)

    changed = (
        original != df["Direction_Clean"]
    ).sum()

    log.append({
        "step": "direction",
        "action": "Standardised Entry/Exit and IN/OUT values",
        "rows_affected": int(changed)
    })

    return df


def check_missing_badge_id(df, log):
    """Flag rows where Badge_ID is missing."""

    df = df.copy()

    df["Badge_ID_Missing"] = df["Badge_ID"].isna()

    missing_count = df["Badge_ID_Missing"].sum()

    log.append({
        "step": "badge_id",
        "action": "Flagged missing Badge_ID values",
        "rows_affected": int(missing_count)
    })

    return df


def check_employee_identity(df, log):
    """
    Check whether a Badge_ID normally belongs to a different Employee_ID.

    The employee ID is not changed automatically. Any mismatch is
    simply flagged for review.
    """

    df = df.copy()

    # Find the most common employee linked to each badge
    badge_employee_map = (
        df
        .dropna(subset=["Badge_ID"])
        .groupby("Badge_ID")["Employee_ID"]
        .agg(lambda x: x.mode().iloc[0])
        .to_dict()
    )

    df["Employee_ID_Expected"] = df[
        "Badge_ID"
    ].map(badge_employee_map)

    df["Employee_Identity_Mismatch"] = (
        df["Badge_ID"].notna()
        & df["Employee_ID_Expected"].notna()
        & (
            df["Employee_ID"]
            != df["Employee_ID_Expected"]
        )
    )

    mismatch_count = df[
        "Employee_Identity_Mismatch"
    ].sum()

    log.append({
        "step": "employee_identity",
        "action": (
            "Checked whether Employee_ID matches the usual owner "
            "of the Badge_ID and flagged mismatches"
        ),
        "rows_affected": int(mismatch_count)
    })

    return df


def check_reason(df, log):
    """
    Missing reasons are recorded, but only denied access records with
    no reason are treated as exceptions.
    """

    df = df.copy()

    missing_reason_count = df["Reason"].isna().sum()

    log.append({
        "step": "reason",
        "action": "Checked for missing Reason values",
        "rows_affected": int(missing_reason_count)
    })

    # A denied access record should normally have a reason
    df["Denied_Missing_Reason"] = (
        (df["Access_Result_Clean"] == "Denied")
        & df["Reason"].isna()
    )

    denied_missing_count = df[
        "Denied_Missing_Reason"
    ].sum()

    log.append({
        "step": "reason",
        "action": "Flagged denied access records with no reason",
        "rows_affected": int(denied_missing_count)
    })

    return df


def flag_sensitive_columns(df, log):
    """
    Keep sensitive fields unchanged but add flags so they can be
    identified later.
    """

    df = df.copy()

    df["Contractor_Group_Sensitive"] = True
    df["Home_Zone_Sensitive"] = True

    log.append({
        "step": "contractor_group",
        "action": "Marked Contractor_Group as potentially sensitive",
        "rows_affected": len(df)
    })

    log.append({
        "step": "home_zone",
        "action": "Marked Home_Zone as potentially sensitive",
        "rows_affected": len(df)
    })

    return df


def create_exceptions(df):
    """Create a table containing rows that need manual review."""

    exception_reasons = []

    for _, row in df.iterrows():

        reasons = []

        # Event time could not be parsed
        if pd.isna(row.get("Event_Time_Clean")):
            reasons.append("Unparseable Event_Time")

        # Event time does not follow the normal pattern
        if row.get("Event_Time_Anomaly"):
            reasons.append(
                "Event_Time does not follow the normal event pattern"
            )

        # Missing badge
        if row.get("Badge_ID_Missing"):
            reasons.append("Missing Badge_ID")

        # Employee ID does not match the normal badge owner
        if row.get("Employee_Identity_Mismatch"):

            reasons.append(
                f"Employee_ID '{row.get('Employee_ID')}' does not match "
                f"the usual owner of Badge_ID "
                f"(expected '{row.get('Employee_ID_Expected')}')"
            )

        # Denied access without a reason
        if row.get("Denied_Missing_Reason"):
            reasons.append(
                "Access_Result is Denied but no Reason was recorded"
            )

        if reasons:
            exception_reasons.append("; ".join(reasons))
        else:
            exception_reasons.append(None)

    df = df.copy()

    df["exception_reason"] = exception_reasons

    exceptions = df[
        df["exception_reason"].notna()
    ].copy()

    return exceptions


def run_pipeline():

    log = []

    # Load the Access_Control sheet
    df = pd.read_excel(
        RAW_PATH,
        sheet_name="Access_Control"
    )

    print(f"Loaded {len(df)} raw rows")

    # Run the cleaning steps
    df = remove_duplicates(df, log)

    df = clean_event_time(df, log)

    df = check_event_time_pattern(df, log)

    df = clean_access_result(df, log)

    df = clean_direction(df, log)

    df = check_missing_badge_id(df, log)

    df = check_employee_identity(df, log)

    df = check_reason(df, log)

    df = flag_sensitive_columns(df, log)

    # Build the exception report
    exceptions_df = create_exceptions(df)

    # Save cleaned data
    df.to_csv(
        OUT_PATH,
        index=False
    )

    # Save exceptions
    exceptions_df.to_csv(
        EXCEPTIONS_PATH,
        index=False
    )

    # Save change log
    pd.DataFrame(log).to_csv(
        CHANGELOG_PATH,
        index=False
    )

    # Print summary
    print(f"\nFinal row count: {len(df)}")

    print(
        f"Rows with at least one exception: "
        f"{len(exceptions_df)}"
    )

    print("\nChange log:")

    for item in log:

        print(
            f"[{item['step']}] "
            f"{item['action']} "
            f"- {item['rows_affected']} rows"
        )

    print("\nFiles saved:")

    print(f"  {OUT_PATH}")
    print(f"  {EXCEPTIONS_PATH}")
    print(f"  {CHANGELOG_PATH}")

    print("\nException summary:")

    print(
        exceptions_df[
            ["Access_Event_ID", "exception_reason"]
        ].to_string(index=False)
    )

    return df, exceptions_df, log


if __name__ == "__main__":
    run_pipeline()
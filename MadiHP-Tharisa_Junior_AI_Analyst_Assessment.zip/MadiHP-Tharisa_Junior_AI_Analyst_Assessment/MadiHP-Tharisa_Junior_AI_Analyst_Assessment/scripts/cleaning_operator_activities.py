"""
clean_operator_activities.py

Cleans and validates the Operator_Activities sheet.

Main checks:
- Remove exact duplicate rows
- Recover missing Operator_ID values where there is enough matching evidence
- Standardise equipment names
- Parse activity start and end dates
- Standardise activity types
- Normalise mobile numbers before hashing
- Flag suspicious quantity units
- Check for negative activity durations
- Flag unusually large quantities
- Hash direct personal information
- Mark sensitive proxy fields
- Create an exceptions file and change log
"""

import hashlib
import pandas as pd

from utils import canonicalize_equipment_names, parse_dates


RAW_PATH = "../raw/source_data.xlsx"
OUT_PATH = "../cleaned/operator_activities_cleaned.csv"
EXCEPTIONS_PATH = "../cleaned/operator_activities_exceptions.csv"
CHANGELOG_PATH = "../reports/operator_activities_changelog.csv"


# Known activity type typo
ACTIVITY_TYPE_MAP = {
    "hualing": "hauling"
}

# Direct personal information
PII_COLUMNS = [
    "Operator_Name",
    "Email",
    "Mobile_Number"
]

# Fields that may act as proxy variables
SENSITIVE_COLUMNS = [
    "Home_Zone",
    "Contractor_Group"
]


def hash_value(value):
    """
    Create a consistent one-way hash.

    The same value will always produce the same hash,
    allowing records to be compared without keeping the
    original personal information.
    """

    if pd.isna(value):
        return None

    value = str(value).strip().lower()

    return hashlib.sha256(
        value.encode()
    ).hexdigest()[:12]


def remove_duplicates(df, log):
    """Remove rows that are completely identical."""

    before = len(df)

    df = df.drop_duplicates(
        keep="first"
    ).copy()

    removed = before - len(df)

    if removed > 0:
        log.append({
            "step": "duplicates",
            "action": "Removed exact duplicate rows",
            "rows_affected": int(removed)
        })

    return df


def recover_missing_operator_id(df, log):
    """
    Try to recover missing Operator_ID values using existing
    operator records.

    The ID is only recovered when the operator name matches
    an existing record in the dataset.
    """

    df = df.copy()

    operator_map = (
        df
        .dropna(subset=["Operator_ID"])
        .drop_duplicates(subset=["Operator_Name"])
        .set_index("Operator_Name")["Operator_ID"]
    )

    missing_mask = df["Operator_ID"].isna()

    missing_count = missing_mask.sum()
    recovered_count = 0

    for index in df[missing_mask].index:

        operator_name = df.at[
            index,
            "Operator_Name"
        ]

        if operator_name in operator_map.index:

            df.at[
                index,
                "Operator_ID"
            ] = operator_map[operator_name]

            recovered_count += 1

    if missing_count > 0:

        log.append({
            "step": "operator_id",
            "action": (
                "Recovered missing Operator_ID values "
                "using matching existing operator records"
            ),
            "rows_affected": int(recovered_count)
        })

    return df


def clean_activity_type(df, log):
    """
    Standardise activity type casing and correct known typos.
    """

    df = df.copy()

    original = df["Activity_Type"].astype(
        "string"
    )

    cleaned = (
        original
        .str.strip()
        .str.lower()
        .replace(ACTIVITY_TYPE_MAP)
        .str.title()
    )

    df["Activity_Type_Clean"] = cleaned

    changed = (
        original != cleaned
    ).sum()

    log.append({
        "step": "activity_type",
        "action": (
            "Standardised activity type values "
            "and corrected 'hualing' to 'Hauling'"
        ),
        "rows_affected": int(changed)
    })

    return df


def normalize_mobile_numbers(df, log):
    """
    Convert mobile numbers to digits only.

    The normalised value is only used when creating the hash
    and is removed before the cleaned file is saved.
    """

    df = df.copy()

    original = df["Mobile_Number"].astype(
        "string"
    )

    df["_Mobile_Number_Normalized"] = (
        original
        .str.replace(
            r"\D",
            "",
            regex=True
        )
    )

    changed = (
        df["_Mobile_Number_Normalized"] != original
    ).sum()

    log.append({
        "step": "mobile_number",
        "action": (
            "Normalised mobile numbers to digits only "
            "before hashing"
        ),
        "rows_affected": int(changed)
    })

    return df


def check_quantity_unit(df, log):
    """
    Flag quantity units that appear inconsistent.

    'tonnes' is treated as suspicious because it appears on
    activity types where a quantity in tonnes does not make sense.
    """

    df = df.copy()

    df["Quantity_Unit_Issue"] = (
        df["Quantity_Unit"]
        .astype(str)
        .str.strip()
        .str.lower()
        .eq("tonnes")
    )

    issue_count = df[
        "Quantity_Unit_Issue"
    ].sum()

    log.append({
        "step": "quantity_unit",
        "action": (
            "Flagged 'tonnes' as a potentially incorrect "
            "quantity unit"
        ),
        "rows_affected": int(issue_count)
    })

    return df


def check_activity_duration(df, log):
    """
    Flag records where Activity_End occurs before Activity_Start.
    """

    df = df.copy()

    df["Duration_Negative"] = (
        df["Activity_Start_Clean"].notna()
        & df["Activity_End_Clean"].notna()
        & (
            df["Activity_End_Clean"]
            < df["Activity_Start_Clean"]
        )
    )

    negative_count = df[
        "Duration_Negative"
    ].sum()

    log.append({
        "step": "activity_duration",
        "action": (
            "Flagged records where Activity_End occurs "
            "before Activity_Start"
        ),
        "rows_affected": int(negative_count)
    })

    return df


def check_quantity_outliers(df, log):
    """
    Flag unusually large quantity values.

    The threshold is based on ten times the median quantity
    in the dataset.
    """

    df = df.copy()

    threshold = (
        df["Quantity"].median() * 10
    )

    df["Quantity_Outlier"] = (
        df["Quantity"] > threshold
    )

    outlier_count = df[
        "Quantity_Outlier"
    ].sum()

    log.append({
        "step": "quantity",
        "action": (
            f"Flagged Quantity values greater than "
            f"10 times the median ({threshold:.0f})"
        ),
        "rows_affected": int(outlier_count)
    })

    return df


def handle_pii(df, log):
    """
    Hash direct personal information.

    Home_Zone and Contractor_Group are kept in the dataset
    but marked as sensitive context fields.
    """

    df = df.copy()

    df["Operator_Name_Hashed"] = (
        df["Operator_Name"]
        .apply(hash_value)
    )

    df["Email_Hashed"] = (
        df["Email"]
        .apply(hash_value)
    )

    df["Mobile_Number_Hashed"] = (
        df["_Mobile_Number_Normalized"]
        .apply(hash_value)
    )

    log.append({
        "step": "pii_handling",
        "action": (
            "Hashed Operator_Name, Email and Mobile_Number "
            "for the cleaned output"
        ),
        "rows_affected": len(df)
    })

    df["Home_Zone_Sensitive"] = True
    df["Contractor_Group_Sensitive"] = True

    log.append({
        "step": "sensitive_fields",
        "action": (
            "Marked Home_Zone and Contractor_Group "
            "as sensitive context fields"
        ),
        "rows_affected": len(df)
    })

    return df


def build_exceptions(df):
    """Create a table containing records that need review."""

    exception_reasons = []

    for _, row in df.iterrows():

        reasons = []

        if pd.isna(
            row.get("Equipment_Name_Clean")
        ):
            reasons.append(
                "Unresolved equipment name"
            )

        if (
            pd.isna(
                row.get("Activity_Start_Clean")
            )
            or pd.isna(
                row.get("Activity_End_Clean")
            )
        ):
            reasons.append(
                "Unparseable activity start or end time"
            )

        if pd.isna(
            row.get("Operator_ID")
        ):
            reasons.append(
                "Operator_ID could not be recovered"
            )

        if row.get(
            "Duration_Negative"
        ):
            reasons.append(
                "Activity_End occurs before Activity_Start"
            )

        if row.get(
            "Quantity_Outlier"
        ):
            reasons.append(
                f"Quantity {row['Quantity']} is unusually large"
            )

        if row.get(
            "Quantity_Unit_Issue"
        ):
            reasons.append(
                "Quantity_Unit 'tonnes' may be incorrect"
            )

        if reasons:

            exception_reasons.append(
                "; ".join(reasons)
            )

        else:

            exception_reasons.append(None)

    df = df.copy()

    df["exception_reason"] = exception_reasons

    return df[
        df["exception_reason"].notna()
    ].copy()


def run_pipeline():

    log = []

    # Load the Operator_Activities sheet
    df = pd.read_excel(
        RAW_PATH,
        sheet_name="Operator_Activities"
    )

    print(f"Loaded {len(df)} raw rows")

    # Run cleaning and validation steps
    df = remove_duplicates(
        df,
        log
    )

    df = recover_missing_operator_id(
        df,
        log
    )

    df = canonicalize_equipment_names(
        df,
        log
    )

    df = parse_dates(
        df,
        log,
        column="Activity_Start"
    )

    df = parse_dates(
        df,
        log,
        column="Activity_End"
    )

    df = clean_activity_type(
        df,
        log
    )

    df = normalize_mobile_numbers(
        df,
        log
    )

    df = check_quantity_unit(
        df,
        log
    )

    df = check_activity_duration(
        df,
        log
    )

    df = check_quantity_outliers(
        df,
        log
    )

    df = handle_pii(
        df,
        log
    )

    # Build exceptions table
    exceptions_df = build_exceptions(df)

    # Remove original personal information before saving
    columns_to_remove = (
        PII_COLUMNS
        + ["_Mobile_Number_Normalized"]
    )

    df_to_save = df.drop(
        columns=columns_to_remove
    )

    # Save outputs
    df_to_save.to_csv(
        OUT_PATH,
        index=False
    )

    exceptions_df.to_csv(
        EXCEPTIONS_PATH,
        index=False
    )

    pd.DataFrame(log).to_csv(
        CHANGELOG_PATH,
        index=False
    )

    # Print summary
    print(f"\nFinal row count: {len(df)}")

    print(
        f"Rows with at least one exception: "
        f"{len(exceptions_df)}"
    )

    print(
        f"\nChange log ({len(log)} entries):"
    )

    for entry in log:

        print(
            f"  [{entry['step']}] "
            f"{entry['action']} - "
            f"{entry['rows_affected']} rows"
        )

    print("\nSaved files:")

    print(f"  {OUT_PATH}")
    print(f"  {EXCEPTIONS_PATH}")
    print(f"  {CHANGELOG_PATH}")

    return df, exceptions_df, log


if __name__ == "__main__":
    run_pipeline()
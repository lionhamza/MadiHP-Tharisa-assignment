"""
clean_equipment_events.py

Clean and validate the Equipment_Events sheet.

The script:
- Removes exact duplicate rows
- Standardises equipment names
- Parses mixed Event_Time formats
- Cleans Status and Event_Type values
- Checks inconsistent Meter_Unit values
- Flags unusual meter readings
- Handles missing comments
- Creates cleaned data, exceptions, and a change log
"""

import re
import pandas as pd


RAW_PATH = "../raw/source_data.xlsx"
OUT_PATH = "../cleaned/equipment_events_cleaned.csv"
EXCEPTIONS_PATH = "../cleaned/equipment_events_exceptions.csv"
CHANGELOG_PATH = "../reports/equipment_events_changelog.csv"


# Known variations of equipment names
EQUIPMENT_NAME_MAP = {
    "EX 001": "EXC-01",
    "EXC001": "EXC-01",
    "EXC-01": "EXC-01",
    "Excavator 1": "EXC-01",

    "EXC-02": "EXC-02",
    "EXC002": "EXC-02",

    "TRK-001": "TRK-001",
    "TRK 001": "TRK-001",
    "truck01": "TRK-001",
    "Truck 1": "TRK-001",

    "TRK002": "TRK-002",
    "Truck 2": "TRK-002",
    "truck02": "TRK-002",

    "TRK-003": "TRK-003",
    "TRK003": "TRK-003",
    "Truck 3": "TRK-003",
    "truck03": "TRK-003",

    "DRL001": "DRL-01",
    "Drill 01": "DRL-01"
}


# Supported Event_Time formats
DATE_PATTERNS = [
    (
        r"^\d{2}/\d{2}/\d{4} \d{2}:\d{2}$",
        "%d/%m/%Y %H:%M",
        "DD/MM/YYYY 24hr"
    ),
    (
        r"^\d{2}/\d{2}/\d{4} \d{2}:\d{2} (AM|PM)$",
        "%m/%d/%Y %I:%M %p",
        "MM/DD/YYYY 12hr"
    ),
    (
        r"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}$",
        "%Y/%m/%d %H:%M",
        "YYYY/MM/DD 24hr"
    ),
    (
        r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$",
        "%Y-%m-%d %H:%M:%S",
        "YYYY-MM-DD"
    )
]


# Known typo in Event_Type
EVENT_TYPE_MAP = {
    "strat": "start"
}


def remove_duplicates(df, log):
    """Remove rows that are completely identical."""

    before = len(df)

    df = df.drop_duplicates(
        keep="first"
    ).copy()

    removed = before - len(df)

    if removed:
        log.append({
            "step": "duplicates",
            "action": "Removed exact duplicate rows",
            "rows_affected": removed
        })

    return df


def clean_equipment_names(df, log):
    """Standardise known equipment name variations."""

    df = df.copy()

    df["Equipment_Name_Clean"] = (
        df["Equipment_Name"]
        .map(EQUIPMENT_NAME_MAP)
    )

    changed = (
        df["Equipment_Name"]
        != df["Equipment_Name_Clean"]
    ).sum()

    log.append({
        "step": "equipment_name",
        "action": "Standardised known equipment name variations",
        "rows_affected": int(changed)
    })

    unresolved = (
        df["Equipment_Name_Clean"]
        .isna()
        .sum()
    )

    if unresolved:
        log.append({
            "step": "equipment_name",
            "action": "Flagged equipment names that could not be mapped",
            "rows_affected": int(unresolved)
        })

    return df


def parse_single_datetime(value):
    """Parse one Event_Time value using the supported formats."""

    if pd.isna(value):
        return None, None

    value = str(value).strip()

    for pattern, date_format, label in DATE_PATTERNS:

        if re.match(pattern, value):

            try:
                parsed_date = pd.to_datetime(
                    value,
                    format=date_format
                )

                return parsed_date, label

            except ValueError:
                continue

    return None, None


def parse_event_times(df, log):
    """Parse Event_Time values using the supported date formats."""

    df = df.copy()

    results = df["Event_Time"].apply(
        parse_single_datetime
    )

    df["Event_Time_Clean"] = results.apply(
        lambda x: x[0]
    )

    df["Event_Time_Format"] = results.apply(
        lambda x: x[1]
    )

    parsed_count = (
        df["Event_Time_Clean"]
        .notna()
        .sum()
    )

    unparsed_count = (
        df["Event_Time_Clean"]
        .isna()
        .sum()
    )

    log.append({
        "step": "event_time",
        "action": "Parsed Event_Time values using supported formats",
        "rows_affected": int(parsed_count)
    })

    if unparsed_count:
        log.append({
            "step": "event_time",
            "action": "Flagged Event_Time values that could not be parsed",
            "rows_affected": int(unparsed_count)
        })

    return df


def clean_status(df, log):
    """Standardise Status casing."""

    df = df.copy()

    original = df["Status"].copy()

    df["Status_Clean"] = (
        df["Status"]
        .astype("string")
        .str.strip()
        .str.title()
    )

    changed = (
        original != df["Status_Clean"]
    ).sum()

    log.append({
        "step": "status",
        "action": "Standardised Status casing",
        "rows_affected": int(changed)
    })

    return df


def clean_event_type(df, log):
    """Standardise Event_Type values and fix known typos."""

    df = df.copy()

    original = (
        df["Event_Type"]
        .astype("string")
    )

    cleaned = (
        original
        .str.strip()
        .str.lower()
        .replace(EVENT_TYPE_MAP)
        .str.title()
    )

    df["Event_Type_Clean"] = cleaned

    changed = (
        original != cleaned
    ).sum()

    log.append({
        "step": "event_type",
        "action": "Standardised Event_Type casing and corrected known typos",
        "rows_affected": int(changed)
    })

    return df


def check_meter_units(df, log):
    """
    Flag rows where Meter_Unit is recorded as minutes.

    Meter readings marked as 'mins' appear on the same numeric scale
    as readings marked as 'hours', so the values are not automatically
    converted.
    """

    df = df.copy()

    df["Meter_Reading_Hours"] = (
        df["Meter_Reading"]
    )

    df["Meter_Unit_Unreliable"] = (
        df["Meter_Unit"]
        .astype("string")
        .str.strip()
        .str.lower()
        == "mins"
    )

    affected = (
        df["Meter_Unit_Unreliable"]
        .sum()
    )

    log.append({
        "step": "meter_unit",
        "action": (
            "Flagged 'mins' meter units because their readings "
            "are on the same scale as 'hours' values"
        ),
        "rows_affected": int(affected)
    })

    return df


def check_meter_readings(df, log):
    """
    Flag unusually large or small meter readings.

    The median is used as a reference so extreme values such as
    placeholder or sentinel readings can be identified.
    """

    df = df.copy()

    median = (
        df["Meter_Reading_Hours"]
        .median()
    )

    df["Meter_Reading_Outlier"] = (
        (
            df["Meter_Reading_Hours"]
            > median * 5
        )
        |
        (
            df["Meter_Reading_Hours"]
            < median / 5
        )
    )

    outlier_count = (
        df["Meter_Reading_Outlier"]
        .sum()
    )

    log.append({
        "step": "meter_reading",
        "action": (
            "Flagged meter readings that are more than five times "
            "above or below the median"
        ),
        "rows_affected": int(outlier_count)
    })

    return df


def check_missing_comments(df, log):
    """Mark rows where no comment was provided."""

    df = df.copy()

    df["Comment_Missing"] = (
        df["Comment"]
        .isna()
    )

    df["Comment_Clean"] = (
        df["Comment"]
        .fillna("(no comment provided)")
    )

    missing_count = (
        df["Comment_Missing"]
        .sum()
    )

    log.append({
        "step": "comment",
        "action": "Marked missing comments",
        "rows_affected": int(missing_count)
    })

    return df


def build_exceptions(df):
    """Create a table containing rows that need review."""

    exception_reasons = []

    for _, row in df.iterrows():

        reasons = []

        if pd.isna(
            row.get("Equipment_Name_Clean")
        ):
            reasons.append(
                "Unresolved equipment name"
            )

        if pd.isna(
            row.get("Event_Time_Clean")
        ):
            reasons.append(
                "Unparseable Event_Time"
            )

        if row.get(
            "Meter_Unit_Unreliable"
        ):
            reasons.append(
                "Meter_Unit is 'mins' but the reading is on "
                "the same scale as 'hours' values"
            )

        if row.get(
            "Meter_Reading_Outlier"
        ):
            reasons.append(
                "Meter reading appears to be an outlier or sentinel value"
            )

        if reasons:
            exception_reasons.append(
                "; ".join(reasons)
            )
        else:
            exception_reasons.append(None)

    df = df.copy()

    df["exception_reason"] = exception_reasons

    return df[
        df["exception_reason"].notna()
    ].copy()


def run_pipeline():
    """Run the Equipment_Events cleaning pipeline."""

    log = []

    # Load the Equipment_Events sheet
    df = pd.read_excel(
        RAW_PATH,
        sheet_name="Equipment_Events"
    )

    print(
        f"Loaded {len(df)} raw rows"
    )

    # Run cleaning and validation steps
    df = remove_duplicates(df, log)
    df = clean_equipment_names(df, log)
    df = parse_event_times(df, log)
    df = clean_status(df, log)
    df = clean_event_type(df, log)
    df = check_meter_units(df, log)
    df = check_meter_readings(df, log)
    df = check_missing_comments(df, log)

    # Create exception rows
    exceptions_df = build_exceptions(df)

    # Save outputs
    df.to_csv(
        OUT_PATH,
        index=False
    )

    exceptions_df.to_csv(
        EXCEPTIONS_PATH,
        index=False
    )

    pd.DataFrame(log).to_csv(
        CHANGELOG_PATH,
        index=False
    )

    # Print summary
    print(
        f"\nFinal row count: {len(df)}"
    )

    print(
        f"Rows with at least one exception: "
        f"{len(exceptions_df)}"
    )

    print(
        f"\nChange log ({len(log)} entries):"
    )

    for entry in log:

        print(
            f"  [{entry['step']}] "
            f"{entry['action']} - "
            f"{entry['rows_affected']} rows"
        )

    print("\nSaved files:")
    print(f"  {OUT_PATH}")
    print(f"  {EXCEPTIONS_PATH}")
    print(f"  {CHANGELOG_PATH}")

    if not exceptions_df.empty:

        print("\nException rows:")

        columns = [
            "Event_ID",
            "Equipment_Name",
            "Event_Time",
            "Meter_Reading",
            "Meter_Unit",
            "exception_reason"
        ]

        print(
            exceptions_df[
                columns
            ].to_string(
                index=False
            )
        )

    return df, exceptions_df, log


if __name__ == "__main__":
    run_pipeline()
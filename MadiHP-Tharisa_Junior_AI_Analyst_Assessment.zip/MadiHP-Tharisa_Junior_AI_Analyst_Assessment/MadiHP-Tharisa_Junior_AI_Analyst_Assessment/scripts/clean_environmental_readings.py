"""
Clean the Environmental_Readings sheet.

This script:
- Removes exact duplicate rows
- Parses mixed date and time formats
- Checks for unusual timestamps
- Cleans equipment names using the existing equipment mapping
- Checks whether each reading type uses the correct unit
- Flags impossible or suspicious values
- Creates a cleaned dataset, exception report, and change log
"""

import re
import pandas as pd


RAW_PATH = "../raw/source_data.xlsx"
OUT_PATH = "../cleaned/environmental_readings_cleaned.csv"
EXCEPTIONS_PATH = "../cleaned/environmental_readings_exceptions.csv"
CHANGELOG_PATH = "../reports/environmental_readings_changelog.csv"


# Date/time formats found in the dataset
DATE_PATTERNS = [
    (
        r"^\d{2}/\d{2}/\d{4} \d{2}:\d{2}$",
        "%d/%m/%Y %H:%M",
        "DD/MM/YYYY 24hr"
    ),
    (
        r"^\d{2}/\d{2}/\d{4} \d{2}:\d{2} (AM|PM)$",
        "%m/%d/%Y %I:%M %p",
        "MM/DD/YYYY 12hr"
    ),
    (
        r"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}$",
        "%Y/%m/%d %H:%M",
        "YYYY/MM/DD 24hr"
    ),
    (
        r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$",
        "%Y-%m-%d %H:%M:%S",
        "ISO"
    ),
]


# Calibration_Due follows a repeating sequence of date formats.
# This was verified by checking that the parsed dates increase
# consistently by one day.
CALIBRATION_DUE_CYCLE = [
    "%d/%m/%Y",
    "%m/%d/%Y",
    "%Y/%m/%d",
    "%Y-%m-%d"
]


# Standard equipment names used across the project
EQUIPMENT_NAME_MAP = {
    "EX 001": "EXC-01",
    "EXC001": "EXC-01",
    "EXC-01": "EXC-01",
    "Excavator 1": "EXC-01",

    "EXC-02": "EXC-02",
    "EXC002": "EXC-02",
    "Excavator 2": "EXC-02",

    "TRK-001": "TRK-001",
    "TRK001": "TRK-001",
    "TRK 001": "TRK-001",
    "truck01": "TRK-001",
    "Truck 1": "TRK-001",

    "TRK-002": "TRK-002",
    "TRK002": "TRK-002",
    "Truck 2": "TRK-002",
    "truck02": "TRK-002",

    "TRK-003": "TRK-003",
    "TRK003": "TRK-003",
    "Truck 3": "TRK-003",
    "truck03": "TRK-003",

    "DRL001": "DRL-01",
    "Drill 01": "DRL-01",
    "DRILL-1": "DRL-01",
    "DRL-01": "DRL-01",
}


CADENCE_TOLERANCE_HOURS = 1


# Expected unit for each type of environmental reading
VALID_UNITS = {
    "Rainfall": "mm",
    "Temperature": "C",
    "Noise": "dB",
    "Dust": "mg/m3",
}


# Very large dust values are likely placeholder or invalid values
DUST_SENTINEL_THRESHOLD = 1000


def drop_exact_duplicates(df, log):
    """Remove rows that are completely identical."""

    original_rows = len(df)

    df = df.drop_duplicates(keep="first").copy()

    removed = original_rows - len(df)

    if removed > 0:
        log.append({
            "step": "duplicates",
            "action": "Removed exact duplicate rows",
            "rows_affected": removed
        })

    return df


def parse_datetime_value(value):
    """Try to parse a value using the known date/time formats."""

    if pd.isna(value):
        return None, None

    value = str(value).strip()

    for pattern, date_format, label in DATE_PATTERNS:

        if re.match(pattern, value):

            try:
                parsed_date = pd.to_datetime(
                    value,
                    format=date_format
                )

                return parsed_date, label

            except ValueError:
                pass

    return None, None


def parse_reading_time(df, log):
    """Parse the Reading_Time column."""

    df = df.copy()

    results = df["Reading_Time"].apply(parse_datetime_value)

    df["Reading_Time_Clean"] = results.apply(lambda x: x[0])

    df["Reading_Time_Format_Detected"] = results.apply(
        lambda x: x[1]
    )

    invalid_count = df["Reading_Time_Clean"].isna().sum()

    log.append({
        "step": "reading_time",
        "action": "Parsed Reading_Time using the detected date formats",
        "rows_affected": len(df)
    })

    if invalid_count > 0:
        log.append({
            "step": "reading_time",
            "action": "Flagged Reading_Time values that could not be parsed",
            "rows_affected": int(invalid_count)
        })

    return df


def flag_reading_time_anomaly(df, log):
    """
    Check whether timestamps follow the normal reading pattern.

    The expected interval is calculated from the median time difference
    between consecutive readings.
    """

    df = df.copy().reset_index(drop=True)

    timestamps = df["Reading_Time_Clean"]

    gaps = timestamps.diff().dropna()

    if len(gaps):
        expected_gap = gaps.median()
    else:
        expected_gap = pd.Timedelta(0)

    first_time = timestamps.iloc[0]

    expected_times = [
        first_time + expected_gap * i
        for i in range(len(df))
    ]

    df["Reading_Time_Expected"] = expected_times

    difference_hours = (
        df["Reading_Time_Clean"] -
        df["Reading_Time_Expected"]
    ).abs().dt.total_seconds() / 3600

    df["Reading_Time_Anomaly"] = (
        df["Reading_Time_Clean"].notna()
        & (difference_hours > CADENCE_TOLERANCE_HOURS)
    )

    anomaly_count = df["Reading_Time_Anomaly"].sum()

    log.append({
        "step": "reading_time_check",
        "action": (
            f"Checked timestamps against the normal reading interval "
            f"of {expected_gap}"
        ),
        "rows_affected": int(anomaly_count)
    })

    return df


def parse_calibration_due(df, log):
    """
    Parse Calibration_Due using the repeating date format pattern.
    """

    df = df.copy()

    cleaned_dates = []

    for index, value in enumerate(df["Calibration_Due"]):

        date_format = CALIBRATION_DUE_CYCLE[
            index % len(CALIBRATION_DUE_CYCLE)
        ]

        try:

            parsed_date = pd.to_datetime(
                str(value).strip(),
                format=date_format
            )

        except (ValueError, TypeError):

            parsed_date = pd.NaT

        cleaned_dates.append(parsed_date)

    df["Calibration_Due_Clean"] = cleaned_dates

    invalid_count = pd.isna(cleaned_dates).sum()

    log.append({
        "step": "calibration_due",
        "action": "Parsed Calibration_Due using the repeating date format pattern",
        "rows_affected": len(df)
    })

    if invalid_count > 0:
        log.append({
            "step": "calibration_due",
            "action": "Flagged Calibration_Due values that could not be parsed",
            "rows_affected": int(invalid_count)
        })

    return df


def clean_equipment_names(df, log):
    """Convert equipment name variations to standard equipment codes."""

    df = df.copy()

    df["Equipment_Nearby_Clean"] = df[
        "Equipment_Nearby"
    ].map(EQUIPMENT_NAME_MAP)

    unresolved = df["Equipment_Nearby_Clean"].isna().sum()

    log.append({
        "step": "equipment_name",
        "action": "Standardised equipment names using the project equipment mapping",
        "rows_affected": len(df) - int(unresolved)
    })

    if unresolved > 0:

        log.append({
            "step": "equipment_name",
            "action": "Flagged equipment names that could not be matched",
            "rows_affected": int(unresolved)
        })

    return df


def flag_unit_mismatch(df, log):
    """Check that each reading type uses the expected unit."""

    df = df.copy()

    expected_units = df["Reading_Type"].map(
        VALID_UNITS
    )

    df["Unit_Mismatch"] = (
        df["Unit"] != expected_units
    )

    mismatch_count = df["Unit_Mismatch"].sum()

    log.append({
        "step": "unit_check",
        "action": "Checked whether the unit matches the reading type",
        "rows_affected": int(mismatch_count)
    })

    return df


def flag_value_issues(df, log):
    """Flag values that are physically impossible or highly suspicious."""

    df = df.copy()

    # Rainfall cannot be negative
    df["Value_Negative_Implausible"] = (
        (df["Reading_Type"] == "Rainfall")
        & (df["Value"] < 0)
    )

    negative_count = df[
        "Value_Negative_Implausible"
    ].sum()

    log.append({
        "step": "value_check",
        "action": "Flagged negative rainfall values",
        "rows_affected": int(negative_count)
    })

    # Very large dust values are likely placeholder values
    df["Value_Likely_Sentinel"] = (
        (df["Reading_Type"] == "Dust")
        & (df["Value"] >= DUST_SENTINEL_THRESHOLD)
    )

    sentinel_count = df[
        "Value_Likely_Sentinel"
    ].sum()

    log.append({
        "step": "value_check",
        "action": (
            f"Flagged Dust readings greater than or equal to "
            f"{DUST_SENTINEL_THRESHOLD}"
        ),
        "rows_affected": int(sentinel_count)
    })

    return df


def build_exceptions(df):
    """Create a dataset containing rows with one or more issues."""

    exceptions = []

    for _, row in df.iterrows():

        issues = []

        if pd.isna(row.get("Reading_Time_Clean")):
            issues.append("Unparseable Reading_Time")

        if row.get("Reading_Time_Anomaly"):
            issues.append(
                "Reading_Time does not follow the normal sensor schedule"
            )

        if pd.isna(row.get("Calibration_Due_Clean")):
            issues.append("Unparseable Calibration_Due")

        if pd.isna(row.get("Equipment_Nearby_Clean")):
            issues.append("Unresolved Equipment_Nearby value")

        if row.get("Unit_Mismatch"):
            issues.append(
                f"Unit '{row['Unit']}' does not match "
                f"Reading_Type '{row['Reading_Type']}'"
            )

        if row.get("Value_Negative_Implausible"):
            issues.append(
                f"Negative rainfall value: {row['Value']}"
            )

        if row.get("Value_Likely_Sentinel"):
            issues.append(
                f"Dust value {row['Value']} may be a placeholder value"
            )

        exceptions.append(
            "; ".join(issues) if issues else None
        )

    df = df.copy()

    df["exception_reason"] = exceptions

    return df[
        df["exception_reason"].notna()
    ].copy()


def run_pipeline():

    log = []

    # Load the Environmental_Readings sheet
    df = pd.read_excel(
        RAW_PATH,
        sheet_name="Environmental_Readings"
    )

    print(f"Loaded {len(df)} raw rows")

    # Run the cleaning steps
    df = drop_exact_duplicates(df, log)

    # Reset the index because some checks depend on row order
    df = df.reset_index(drop=True)

    df = parse_reading_time(df, log)

    df = flag_reading_time_anomaly(df, log)

    df = parse_calibration_due(df, log)

    df = clean_equipment_names(df, log)

    df = flag_unit_mismatch(df, log)

    df = flag_value_issues(df, log)

    # Build the exception report
    exceptions_df = build_exceptions(df)

    # Save the outputs
    df.to_csv(OUT_PATH, index=False)

    exceptions_df.to_csv(
        EXCEPTIONS_PATH,
        index=False
    )

    pd.DataFrame(log).to_csv(
        CHANGELOG_PATH,
        index=False
    )

    # Summary
    print(f"\nFinal row count: {len(df)}")

    print(
        f"Rows with at least one exception: "
        f"{len(exceptions_df)}"
    )

    print("\nChange log:")

    for entry in log:

        print(
            f"  [{entry['step']}] "
            f"{entry['action']} - "
            f"{entry['rows_affected']} rows"
        )

    print("\nFiles saved:")

    print(f"  {OUT_PATH}")
    print(f"  {EXCEPTIONS_PATH}")
    print(f"  {CHANGELOG_PATH}")

    print("\nException summary:")

    print(
        exceptions_df[
            ["Reading_ID", "exception_reason"]
        ].to_string(index=False)
    )

    return df, exceptions_df, log


if __name__ == "__main__":
    run_pipeline()
"""
clean_shift_performance.py

Cleaning pipeline for the Shift_Performance sheet.

The data was reviewed before applying any fixes to make sure that values
were only corrected when there was enough evidence to support the change.

A few issues stood out:

- Shift_Date contains three different date formats. The YYYY/MM/DD and
  YYYY-MM-DD formats are straightforward, but the XX/XX/YYYY format can
  represent either DD/MM/YYYY or MM/DD/YYYY. Since the dataset contains
  July 2026 records, the position of "07" can be used to determine which
  format applies to each value.

- Fuel_Unit contains both litres and gallons. Unlike the mixed minutes and
  hours issue found in Equipment_Events, gallons and litres measure the
  same thing and have a standard conversion factor. Gallon values can
  therefore be safely converted to litres.

- Some records contain values that do not make sense when compared with
  other fields on the same row:

    SHF0005: Actual_Hours is 26 while Scheduled_Hours is 12.

    SHF0033: Availability_Pct is 1.35, which represents 135%.

    SHF0014: Loads is -3, even though Tonnes is a normal positive value.

    SHF0019: Fuel_Used is 0 despite Actual_Hours being 9.

These records are flagged rather than automatically corrected because the
data shows that something is wrong, but does not provide enough information
to determine what the correct value should be.
"""

import pandas as pd
import re
from utils import canonicalize_equipment_names

RAW_PATH = "../raw/source_data.xlsx"
OUT_PATH = "../cleaned/shift_performance_cleaned.csv"
EXCEPTIONS_PATH = "../cleaned/shift_performance_exceptions.csv"
CHANGELOG_PATH = "../reports/shift_performance_changelog.csv"


# Shift_Date does not include a time component, so these formats are
# handled separately from the datetime formats used in other sheets.
DATE_ONLY_ISO_PATTERNS = [
    (r'^\d{4}/\d{2}/\d{2}$', '%Y/%m/%d', 'YYYY/MM/DD'),
    (r'^\d{4}-\d{2}-\d{2}$', '%Y-%m-%d', 'ISO YYYY-MM-DD'),
]

GALLONS_TO_LITRES = 3.78541


def _parse_shift_date(raw_value):
    """
    Parses the different date formats found in Shift_Date.

    The YYYY-first formats are unambiguous. The XX/XX/YYYY format needs
    to be checked per value because the dataset contains both DD/MM/YYYY
    and MM/DD/YYYY formats.

    Since the records are from July 2026:

    - If the second position is 07, the value is treated as DD/MM/YYYY.
      Example: 01/07/2026.

    - If the first position is 07, the value is treated as MM/DD/YYYY.
      Example: 07/13/2026.

    - 07/07/2026 represents the same date either way.
    """
    if pd.isna(raw_value):
        return None, None

    s = str(raw_value).strip()

    for pattern, fmt, label in DATE_ONLY_ISO_PATTERNS:
        if re.match(pattern, s):
            try:
                return pd.to_datetime(s, format=fmt), label
            except ValueError:
                continue

    m = re.match(r'^(\d{2})/(\d{2})/(\d{4})$', s)

    if m:
        pos1, pos2, year = m.groups()

        if pos2 == "07" and pos1 != "07":
            fmt, label = "%d/%m/%Y", "DD/MM/YYYY (pos2 fixed=07)"

        elif pos1 == "07" and pos2 != "07":
            fmt, label = "%m/%d/%Y", "MM/DD/YYYY (pos1 fixed=07)"

        else:
            fmt, label = "%d/%m/%Y", "DD/MM/YYYY (07/07 - same either way)"

        try:
            return pd.to_datetime(s, format=fmt), label
        except ValueError:
            return None, None

    return None, None


# ---------------------------------------------------------------------------
# Remove exact duplicate rows
# ---------------------------------------------------------------------------

def drop_exact_duplicates(df: pd.DataFrame, log: list):
    before = len(df)

    df = df.drop_duplicates(keep="first").copy()

    removed = before - len(df)

    if removed:
        log.append({
            "step": "duplicates",
            "action": "dropped exact duplicate rows",
            "rows_affected": removed
        })

    return df


# ---------------------------------------------------------------------------
# Parse Shift_Date
# ---------------------------------------------------------------------------

def parse_shift_date(df: pd.DataFrame, log: list):
    df = df.copy()

    results = df["Shift_Date"].apply(_parse_shift_date)

    df["Shift_Date_Clean"] = results.apply(lambda t: t[0])
    df["Shift_Date_Format_Detected"] = results.apply(lambda t: t[1])

    counts = df["Shift_Date_Format_Detected"].value_counts(dropna=False)

    for fmt_label, n in counts.items():
        log.append({
            "step": "shift_date",
            "action": f"parsed as {fmt_label}",
            "rows_affected": int(n)
        })

    return df


# ---------------------------------------------------------------------------
# Convert fuel to litres
# ---------------------------------------------------------------------------

def convert_fuel_to_litres(df: pd.DataFrame, log: list):
    """
    Converts Fuel_Used values recorded in gallons to litres.

    Both units measure the same physical quantity, so the standard
    gallon-to-litre conversion can be applied safely.
    """
    df = df.copy()

    df["Fuel_Used_Litres"] = df["Fuel_Used"].astype(float)

    gal_mask = df["Fuel_Unit"].str.lower() == "gallons"

    df.loc[gal_mask, "Fuel_Used_Litres"] = (
        df.loc[gal_mask, "Fuel_Used"] * GALLONS_TO_LITRES
    )

    log.append({
        "step": "fuel_unit",
        "action": "converted gallons to litres using x3.78541",
        "rows_affected": int(gal_mask.sum())
    })

    return df


# ---------------------------------------------------------------------------
# Check Actual_Hours against Scheduled_Hours
# ---------------------------------------------------------------------------

def flag_hours_inconsistency(df: pd.DataFrame, log: list):
    """
    Flags records where Actual_Hours is significantly higher than
    Scheduled_Hours.

    The value is not changed because there is no reliable way to determine
    what the correct number of hours should be.
    """
    df = df.copy()

    df["Hours_Outlier"] = (
        df["Actual_Hours"] > df["Scheduled_Hours"] * 1.5
    )

    n = df["Hours_Outlier"].sum()

    log.append({
        "step": "actual_hours",
        "action": "flagged Actual_Hours far exceeding Scheduled_Hours (>1.5x)",
        "rows_affected": int(n)
    })

    return df


# ---------------------------------------------------------------------------
# Check percentage values
# ---------------------------------------------------------------------------

def flag_pct_out_of_range(df: pd.DataFrame, log: list):
    """
    Flags Availability and Utilisation percentages above 100%.
    """
    df = df.copy()

    df["Availability_Pct_Invalid"] = df["Availability_Pct"] > 1.0
    df["Utilisation_Pct_Invalid"] = df["Utilisation_Pct"] > 1.0

    n_avail = df["Availability_Pct_Invalid"].sum()
    n_util = df["Utilisation_Pct_Invalid"].sum()

    log.append({
        "step": "availability_pct",
        "action": "flagged Availability_Pct above 100%",
        "rows_affected": int(n_avail)
    })

    log.append({
        "step": "utilisation_pct",
        "action": "flagged Utilisation_Pct above 100%",
        "rows_affected": int(n_util)
    })

    return df


# ---------------------------------------------------------------------------
# Check for negative Loads
# ---------------------------------------------------------------------------

def flag_negative_loads(df: pd.DataFrame, log: list):
    """
    Flags negative values in Loads.

    The issue is treated as specific to the Loads field rather than
    assuming that the rest of the record is invalid.
    """
    df = df.copy()

    df["Loads_Negative"] = df["Loads"] < 0

    n = df["Loads_Negative"].sum()

    log.append({
        "step": "loads",
        "action": "flagged negative Loads values",
        "rows_affected": int(n)
    })

    return df


# ---------------------------------------------------------------------------
# Check for zero fuel while equipment was operating
# ---------------------------------------------------------------------------

def flag_zero_fuel(df: pd.DataFrame, log: list):
    """
    Flags records where Fuel_Used is zero even though the equipment shows
    positive Actual_Hours.
    """
    df = df.copy()

    df["Fuel_Zero_While_Working"] = (
        (df["Fuel_Used"] == 0)
        & (df["Actual_Hours"] > 0)
    )

    n = df["Fuel_Zero_While_Working"].sum()

    log.append({
        "step": "fuel_used",
        "action": "flagged Fuel_Used=0 despite Actual_Hours>0",
        "rows_affected": int(n)
    })

    return df


# ---------------------------------------------------------------------------
# Build exceptions table
# ---------------------------------------------------------------------------

def build_exceptions(df: pd.DataFrame):
    reasons = []

    for _, row in df.iterrows():
        r = []

        if pd.isna(row.get("Equipment_Name_Clean")):
            r.append("unresolved equipment name")

        if pd.isna(row.get("Shift_Date_Clean")):
            r.append("unparseable shift date")

        if row.get("Hours_Outlier"):
            r.append("Actual_Hours implausibly exceeds Scheduled_Hours")

        if row.get("Availability_Pct_Invalid"):
            r.append("Availability_Pct exceeds 100%")

        if row.get("Utilisation_Pct_Invalid"):
            r.append("Utilisation_Pct exceeds 100%")

        if row.get("Loads_Negative"):
            r.append("negative Loads value")

        if row.get("Fuel_Zero_While_Working"):
            r.append("Fuel_Used=0 despite equipment working")

        reasons.append("; ".join(r) if r else None)

    df = df.copy()
    df["exception_reason"] = reasons

    return df[df["exception_reason"].notna()].copy()


# ---------------------------------------------------------------------------
# Run the cleaning pipeline
# ---------------------------------------------------------------------------

def run_pipeline():
    log = []

    df = pd.read_excel(
        RAW_PATH,
        sheet_name="Shift_Performance"
    )

    print(f"Loaded {len(df)} raw rows")

    df = drop_exact_duplicates(df, log)
    df = canonicalize_equipment_names(df, log)
    df = parse_shift_date(df, log)
    df = convert_fuel_to_litres(df, log)

    df = flag_hours_inconsistency(df, log)
    df = flag_pct_out_of_range(df, log)
    df = flag_negative_loads(df, log)
    df = flag_zero_fuel(df, log)

    exceptions_df = build_exceptions(df)

    df.to_csv(OUT_PATH, index=False)
    exceptions_df.to_csv(EXCEPTIONS_PATH, index=False)
    pd.DataFrame(log).to_csv(CHANGELOG_PATH, index=False)

    print(f"\nFinal row count: {len(df)}")
    print(f"Rows with at least one exception flag: {len(exceptions_df)}")

    print(f"\nChange log ({len(log)} entries):")

    for entry in log:
        print(
            f"  [{entry['step']}] "
            f"{entry['action']} - "
            f"{entry['rows_affected']} rows"
        )

    print(
        f"\nSaved:"
        f"\n  {OUT_PATH}"
        f"\n  {EXCEPTIONS_PATH}"
        f"\n  {CHANGELOG_PATH}"
    )

    print("\nException rows (Shift_Record_ID + reason):")

    print(
        exceptions_df[
            ["Shift_Record_ID", "exception_reason"]
        ].to_string(index=False)
    )

    # The shift fairness analysis is handled separately from cleaning.
    # That analysis should consider both Crew and Equipment_Name so that
    # differences between crews are interpreted with the equipment they
    # were working with, rather than simply ranking crews by performance.

    return df, exceptions_df, log


if __name__ == "__main__":
    run_pipeline()
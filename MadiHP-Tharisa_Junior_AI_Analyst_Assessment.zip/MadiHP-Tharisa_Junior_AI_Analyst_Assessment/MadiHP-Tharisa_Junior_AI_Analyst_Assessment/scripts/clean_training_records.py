"""
clean_training_records.py

Cleans and checks the Training_Records sheet.

Main checks:
- Remove exact duplicate rows
- Standardise inconsistent course codes
- Parse mixed date formats
- Use the expected 730-day certification period to resolve ambiguous dates
- Flag invalid scores
- Check whether Result matches Score
- Mark sensitive fields without changing them
- Create an exceptions file and change log
"""

import re
import pandas as pd


RAW_PATH = "../raw/source_data.xlsx"
OUT_PATH = "../cleaned/training_records_cleaned.csv"
EXCEPTIONS_PATH = "../cleaned/training_records_exceptions.csv"
CHANGELOG_PATH = "../reports/training_records_changelog.csv"


# Known course code variations
COURSE_CODE_MAP = {
    "SAFE-1": "SAFE01"
}

# Certifications normally last exactly two years in this dataset
VALIDITY_DAYS = 730

# Expected score range
MIN_SCORE = 0
MAX_SCORE = 100

# Scores of 70 and above are treated as Pass
PASS_MARK = 70


def remove_duplicates(df, log):
    """Remove rows that are completely identical."""
    before = len(df)

    df = df.drop_duplicates(keep="first").copy()

    removed = before - len(df)

    if removed > 0:
        log.append({
            "step": "duplicates",
            "action": "Removed exact duplicate rows",
            "rows_affected": removed
        })

    return df


def clean_course_codes(df, log):
    """Standardise known course code variations."""
    df = df.copy()

    original = df["Course_Code"].copy()

    df["Course_Code_Clean"] = df["Course_Code"].replace(COURSE_CODE_MAP)

    changed = (original != df["Course_Code_Clean"]).sum()

    if changed > 0:
        log.append({
            "step": "course_code",
            "action": "Standardised SAFE-1 to SAFE01",
            "rows_affected": int(changed)
        })

    return df


def get_date_candidates(value):
    """
    Return possible interpretations of a date.

    DD/MM/YYYY values can also potentially be MM/DD/YYYY,
    so both are returned when valid.
    """
    if pd.isna(value):
        return []

    value = str(value).strip()
    candidates = []

    # ISO: YYYY-MM-DD
    if re.match(r"^\d{4}-\d{2}-\d{2}$", value):
        try:
            date = pd.to_datetime(value, format="%Y-%m-%d")
            candidates.append((date, "YYYY-MM-DD"))
        except ValueError:
            pass

    # YYYY/MM/DD
    elif re.match(r"^\d{4}/\d{2}/\d{2}$", value):
        try:
            date = pd.to_datetime(value, format="%Y/%m/%d")
            candidates.append((date, "YYYY/MM/DD"))
        except ValueError:
            pass

    # Could be either DD/MM/YYYY or MM/DD/YYYY
    elif re.match(r"^\d{2}/\d{2}/\d{4}$", value):

        try:
            date = pd.to_datetime(value, format="%d/%m/%Y")
            candidates.append((date, "DD/MM/YYYY"))
        except ValueError:
            pass

        try:
            date = pd.to_datetime(value, format="%m/%d/%Y")
            candidates.append((date, "MM/DD/YYYY"))
        except ValueError:
            pass

    return candidates


def parse_dates(df, log):
    """
    Parse Completion_Date and Expiry_Date together.

    If a date is ambiguous, try the possible interpretations and keep
    the combination where the certification period is exactly 730 days.

    If no valid combination is found, leave the dates unresolved.
    """
    df = df.copy()

    completion_dates = []
    completion_formats = []

    expiry_dates = []
    expiry_formats = []

    unresolved = []

    for _, row in df.iterrows():

        completion_options = get_date_candidates(
            row["Completion_Date"]
        )

        expiry_options = get_date_candidates(
            row["Expiry_Date"]
        )

        match = None

        for completion_date, completion_format in completion_options:

            for expiry_date, expiry_format in expiry_options:

                days_between = (
                    expiry_date - completion_date
                ).days

                if days_between == VALIDITY_DAYS:

                    match = (
                        completion_date,
                        completion_format,
                        expiry_date,
                        expiry_format
                    )

                    break

            if match:
                break

        if match:

            completion_date, completion_format, \
            expiry_date, expiry_format = match

            completion_dates.append(completion_date)
            completion_formats.append(completion_format)

            expiry_dates.append(expiry_date)
            expiry_formats.append(expiry_format)

            unresolved.append(False)

        else:
            # Do not guess if the dates cannot be reconciled
            completion_dates.append(pd.NaT)
            completion_formats.append(None)

            expiry_dates.append(pd.NaT)
            expiry_formats.append(None)

            unresolved.append(True)

    df["Completion_Date_Clean"] = completion_dates
    df["Completion_Date_Format"] = completion_formats

    df["Expiry_Date_Clean"] = expiry_dates
    df["Expiry_Date_Format"] = expiry_formats

    df["Date_Pair_Unresolved"] = unresolved

    unresolved_count = sum(unresolved)

    log.append({
        "step": "dates",
        "action": (
            "Parsed Completion_Date and Expiry_Date together "
            "using the 730-day certification period to resolve "
            "ambiguous date formats"
        ),
        "rows_affected": len(df)
    })

    if unresolved_count > 0:
        log.append({
            "step": "dates",
            "action": (
                "Flagged date pairs that could not be resolved "
                "to a 730-day certification period"
            ),
            "rows_affected": int(unresolved_count)
        })

    return df


def check_missing_comments(df, log):
    """Record how many Comment values are missing."""
    df = df.copy()

    missing = df["Comment"].isna().sum()

    log.append({
        "step": "comment",
        "action": "Recorded missing Comment values",
        "rows_affected": int(missing)
    })

    return df


def check_scores(df, log):
    """Flag scores outside the expected 0-100 range."""
    df = df.copy()

    df["Score_Out_Of_Range"] = (
        (df["Score"] < MIN_SCORE) |
        (df["Score"] > MAX_SCORE)
    )

    invalid_count = df["Score_Out_Of_Range"].sum()

    log.append({
        "step": "score",
        "action": "Flagged scores outside the 0-100 range",
        "rows_affected": int(invalid_count)
    })

    return df


def check_result_against_score(df, log):
    """
    Check whether Result matches the score rule.

    Score >= 70 should be Pass.
    Scores below 70 should be Fail.

    Rows with invalid scores are ignored because the score itself
    cannot be trusted.
    """
    df = df.copy()

    expected_pass = df["Score"] >= PASS_MARK

    actual_pass = (
        df["Result"]
        .astype(str)
        .str.strip()
        .str.lower()
        == "pass"
    )

    df["Result_Score_Mismatch"] = (
        (expected_pass != actual_pass) &
        ~df["Score_Out_Of_Range"]
    )

    mismatch_count = df["Result_Score_Mismatch"].sum()

    log.append({
        "step": "result_score_check",
        "action": (
            "Flagged rows where Result does not match "
            "the expected Pass/Fail outcome from the score"
        ),
        "rows_affected": int(mismatch_count)
    })

    return df


def mark_sensitive_fields(df, log):
    """
    Keep sensitive fields unchanged but clearly mark them.

    The Data_Dictionary identifies Medical_Fitness_Code as sensitive
    personal information and Home_Zone as potentially sensitive.
    """
    df = df.copy()

    df["Medical_Fitness_Code_Sensitive"] = True
    df["Home_Zone_Sensitive"] = True

    log.append({
        "step": "medical_fitness_code",
        "action": (
            "Marked Medical_Fitness_Code as sensitive "
            "and kept the original values unchanged"
        ),
        "rows_affected": len(df)
    })

    log.append({
        "step": "home_zone",
        "action": (
            "Marked Home_Zone as potentially sensitive "
            "and kept the original values unchanged"
        ),
        "rows_affected": len(df)
    })

    return df


def build_exceptions(df):
    """Create an exceptions table containing rows that need review."""
    exception_reasons = []

    for _, row in df.iterrows():

        reasons = []

        if row.get("Date_Pair_Unresolved"):
            reasons.append(
                "Completion_Date and Expiry_Date could not be "
                "reconciled to the expected 730-day validity period"
            )

        if row.get("Score_Out_Of_Range"):
            reasons.append(
                f"Score {row.get('Score')} is outside "
                f"the valid {MIN_SCORE}-{MAX_SCORE} range"
            )

        if row.get("Result_Score_Mismatch"):
            reasons.append(
                f"Result '{row.get('Result')}' does not match "
                f"Score {row.get('Score')}"
            )

        if reasons:
            exception_reasons.append("; ".join(reasons))
        else:
            exception_reasons.append(None)

    df = df.copy()

    df["exception_reason"] = exception_reasons

    return df[
        df["exception_reason"].notna()
    ].copy()


def run_pipeline():

    log = []

    # Load the Training_Records sheet
    df = pd.read_excel(
        RAW_PATH,
        sheet_name="Training_Records"
    )

    print(f"Loaded {len(df)} raw rows")

    # Run cleaning and validation checks
    df = remove_duplicates(df, log)
    df = clean_course_codes(df, log)
    df = parse_dates(df, log)
    df = check_missing_comments(df, log)
    df = check_scores(df, log)
    df = check_result_against_score(df, log)
    df = mark_sensitive_fields(df, log)

    # Create exception rows
    exceptions_df = build_exceptions(df)

    # Save outputs
    df.to_csv(
        OUT_PATH,
        index=False
    )

    exceptions_df.to_csv(
        EXCEPTIONS_PATH,
        index=False
    )

    pd.DataFrame(log).to_csv(
        CHANGELOG_PATH,
        index=False
    )

    # Summary
    print(f"\nFinal row count: {len(df)}")
    print(
        f"Rows with at least one exception: "
        f"{len(exceptions_df)}"
    )

    print(f"\nChange log ({len(log)} entries):")

    for entry in log:
        print(
            f"  [{entry['step']}] "
            f"{entry['action']} - "
            f"{entry['rows_affected']} rows"
        )

    print("\nSaved files:")
    print(f"  {OUT_PATH}")
    print(f"  {EXCEPTIONS_PATH}")
    print(f"  {CHANGELOG_PATH}")

    if not exceptions_df.empty:

        print("\nException rows:")

        columns = [
            "Training_Record_ID",
            "Operator_ID",
            "Completion_Date",
            "Expiry_Date",
            "Score",
            "exception_reason"
        ]

        print(
            exceptions_df[columns].to_string(
                index=False
            )
        )

    return df, exceptions_df, log


if __name__ == "__main__":
    run_pipeline()
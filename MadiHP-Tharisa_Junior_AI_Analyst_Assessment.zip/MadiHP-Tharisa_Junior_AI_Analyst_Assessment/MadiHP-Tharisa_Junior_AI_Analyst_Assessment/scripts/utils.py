"""
utils.py

Shared cleaning functions used across multiple sheets.

During the early stages of the project, the equipment name cleaning and
date parsing logic were repeated in several scripts. Since the same
equipment naming variations and date formats appear across multiple
datasets, the common logic is kept here and reused where needed.

This keeps the cleaning process consistent and avoids maintaining the
same code in several places.
"""

import re
import pandas as pd


# Standard equipment names used throughout the project.
#
# Most mappings were verified using the meter-reading sequence in the
# Equipment_Events data. Different names were only grouped together where
# the readings formed a continuous sequence, suggesting they referred to
# the same physical machine.
#
# A few additional variants first appeared in Delays_Downtime:
#
#   DRILL-1 -> DRL-01
#   Excavator 2 -> EXC-02
#
# These could not be verified using meter readings because that sheet does
# not contain them. Instead, they were mapped using the known set of
# equipment in the dataset. This is weaker evidence than the meter-reading
# check and is documented as such in the data-quality reporting.

EQUIPMENT_NAME_MAP = {
    "EX 001": "EXC-01",
    "EXC001": "EXC-01",
    "EXC-01": "EXC-01",
    "Excavator 1": "EXC-01",

    "EXC-02": "EXC-02",
    "EXC002": "EXC-02",
    "Excavator 2": "EXC-02",

    "TRK-001": "TRK-001",
    "TRK001": "TRK-001",
    "TRK 001": "TRK-001",
    "truck01": "TRK-001",
    "Truck 1": "TRK-001",

    "TRK-002": "TRK-002",
    "TRK002": "TRK-002",
    "Truck 2": "TRK-002",
    "truck02": "TRK-002",

    "TRK-003": "TRK-003",
    "TRK003": "TRK-003",
    "Truck 3": "TRK-003",
    "truck03": "TRK-003",

    "DRL001": "DRL-01",
    "Drill 01": "DRL-01",
    "DRILL-1": "DRL-01",
    "DRL-01": "DRL-01",
}


# Date and datetime formats found across the source sheets.
# Each value is matched against these patterns before being parsed.

DATE_PATTERNS = [
    (
        r'^\d{2}/\d{2}/\d{4} \d{2}:\d{2}$',
        '%d/%m/%Y %H:%M',
        'DD/MM/YYYY 24hr'
    ),
    (
        r'^\d{2}/\d{2}/\d{4} \d{2}:\d{2} (AM|PM)$',
        '%m/%d/%Y %I:%M %p',
        'MM/DD/YYYY 12hr'
    ),
    (
        r'^\d{4}/\d{2}/\d{2} \d{2}:\d{2}$',
        '%Y/%m/%d %H:%M',
        'YYYY/MM/DD 24hr'
    ),
    (
        r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$',
        '%Y-%m-%d %H:%M:%S',
        'ISO YYYY-MM-DD'
    ),
]


def canonicalize_equipment_names(df: pd.DataFrame, log: list,
                                 column="Equipment_Name"):
    """
    Maps equipment name variations to the standard equipment names.

    A new '<column>_Clean' column is added so the original value is kept
    for traceability.
    """
    df = df.copy()

    clean_column = f"{column}_Clean"
    df[clean_column] = df[column].map(EQUIPMENT_NAME_MAP)

    for raw_value, clean_value in EQUIPMENT_NAME_MAP.items():
        affected = (df[column] == raw_value).sum()

        if affected:
            log.append({
                "step": "equipment_name",
                "action": f"{raw_value!r} -> {clean_value}",
                "rows_affected": int(affected)
            })

    return df


def _parse_one_datetime(raw_value):
    """
    Attempts to parse a single date/datetime value using the formats
    identified in the source data.

    Returns the parsed datetime together with the format that was detected.
    If the value cannot be parsed, both values are returned as None.
    """
    if pd.isna(raw_value):
        return None, None

    value = str(raw_value).strip()

    for pattern, date_format, label in DATE_PATTERNS:
        if re.match(pattern, value):
            try:
                parsed = pd.to_datetime(value, format=date_format)
                return parsed, label
            except ValueError:
                continue

    return None, None


def parse_dates(df: pd.DataFrame, log: list, column):
    """
    Parses a date or datetime column using the supported source formats.

    Two columns are added:

        <column>_Clean
            The parsed datetime value.

        <column>_Format_Detected
            The format that was used to parse the original value.

    Parsing results are also added to the change log.
    """
    df = df.copy()

    results = df[column].apply(_parse_one_datetime)

    df[f"{column}_Clean"] = results.apply(lambda result: result[0])
    df[f"{column}_Format_Detected"] = results.apply(
        lambda result: result[1]
    )

    format_counts = (
        df[f"{column}_Format_Detected"]
        .value_counts(dropna=False)
    )

    for format_label, count in format_counts.items():
        log.append({
            "step": f"{column}_parse",
            "action": f"parsed as {format_label}",
            "rows_affected": int(count)
        })

    return df
# scripts/

This folder contains the Python scripts used to explore, clean, reconcile, and validate the project data.

The scripts are designed to work from the raw source data and produce cleaned datasets, reports, and exception outputs.

## workflow

raw/
 │
 ▼
01_explore.py
 │
 ▼
Cleaning scripts
 │
 ├── clean_equipment_events.py
 ├── clean_delays_downtime.py
 ├── cleaning_maintenance_notifications.py
 ├── cleaning_operator_activities.py
 ├── cleaning_safety_observations.py
 ├── cleaning_shift_performance.py
 ├── clean_environmental_readings.py
 ├── clean_training_records.py
 └── clean_access_control.py
 │
 ▼
03_reconcile.py
 │
 ▼
reports/ + cleaned/
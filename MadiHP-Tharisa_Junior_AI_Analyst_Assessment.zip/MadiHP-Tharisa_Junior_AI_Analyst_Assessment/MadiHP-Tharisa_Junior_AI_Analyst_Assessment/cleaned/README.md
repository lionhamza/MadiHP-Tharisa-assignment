# cleaned/
Your cleaned dataset(s) go here — output of scripts/, never hand-edited.
Suggested naming: cleaned_equipment_events.csv, cleaned_operator_activities.csv, etc.
Also put here: exception_report.csv (records you couldn't confidently resolve).

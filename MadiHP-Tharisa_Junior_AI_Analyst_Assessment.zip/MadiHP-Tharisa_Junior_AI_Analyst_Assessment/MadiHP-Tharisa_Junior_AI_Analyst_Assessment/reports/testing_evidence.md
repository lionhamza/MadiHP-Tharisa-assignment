# Testing Evidence — Project Signal

Approach: since the "correct answer" for most of this data isn't
independently documented anywhere, testing means checking that specific
records I identified by manual inspection of the raw file are the same
ones the pipeline flags automatically — a known-answer test, run against
the actual `cleaned/*_exceptions.csv` output of each script, not a
theoretical claim about what the code should do.

All checks below were re-run against the current output on 2026-08-20;
commands are in `scripts/03_reconcile.py` output and ad-hoc checks kept in
git history / session log.

## Positive tests (row known to have a problem — should be flagged)

| ID | Dataset | Known issue | Expected | Actual | Result |
|---|---|---|---|---|---|
| TRN0008 | Training_Records | Expiry_Date predates Completion_Date under every date reading | Flagged | Flagged: "could not be reconciled with expected ~2yr validity gap" | PASS |
| TRN0015 | Training_Records | Result='Pass' but Score=42 | Flagged | Flagged: "Result 'Pass' disagrees with Score 42" | PASS |
| TRN0023 | Training_Records | Score=145, out of range | Flagged | Flagged: "Score 145 outside plausible 0-100 range" | PASS |
| SAF0006 | Safety_Observations | Closed_Date before Observation_Date + Status/Closed_Date contradiction | Flagged (both symptoms) | Flagged: both reasons present | PASS |
| SAF0020 | Safety_Observations | Critical severity + benign description + missing Closed_Date | Flagged (both symptoms) | Flagged: both reasons present | PASS |
| SAF0027 | Safety_Observations | Free text names an Observed_Person_ID + unverifiable claim | Redacted in cleaned output | `Description` replaced with `[REDACTED...]` marker; raw text absent from cleaned CSV | PASS |
| ENV0016 | Environmental_Readings | Rainfall = -25.0 mm (impossible) | Flagged | Flagged: "negative Rainfall value (-25.0)" | PASS |
| ENV0022 | Environmental_Readings | Dust = 9999.0 mg/m3 (sentinel) | Flagged | Flagged: "looks like a sentinel/placeholder" | PASS |
| ENV0030 | Environmental_Readings | Timestamp 1,290h off the sheet's 3h cadence | Flagged | Flagged: "breaks the regular sensor cadence" | PASS |
| ACC0018 | Access_Control | Employee_ID doesn't match Badge_ID's usual owner | Flagged | Flagged: "disagrees with the Badge_ID/Employee_Name owner (expected 'OP1003')" | PASS |
| ACC0034 | Access_Control | Timestamp ~9,464h off the sheet's 4h cadence | Flagged | Flagged: "breaks the regular badge-event cadence" | PASS |
| DLY0031 | Delays_Downtime | Duration=14,400 min vs. ~60 min calculated from Start/End | Flagged | Flagged: "Duration disagrees with calculated Start/End gap" | PASS |
| DLY0006 | Delays_Downtime | Duration=-45 min (negative) | Flagged | Flagged (negative duration check) | PASS |
| ACT0013 | Operator_Activities | Activity_End before Activity_Start | Flagged | Flagged: "negative duration" | PASS |
| ACT0020 | Operator_Activities | Quantity=450 vs. sheet max ~10 elsewhere | Flagged | Flagged: "Quantity far outside the sheet's normal range" | PASS |
| ACT0029 | Operator_Activities | Equipment_Name="TRK099", not a real machine | Flagged | Flagged: "unresolved equipment name" | PASS |
| SHF0014 | Shift_Performance | Loads negative | Flagged | Flagged: "negative Loads value" | PASS |
| SHF0033 | Shift_Performance | Availability_Pct > 100% | Flagged | Flagged: "Availability_Pct exceeds 100%" | PASS |
| MNT0007 | Maintenance_Notifications | Downtime_Hours disagrees with calculated Actual_Start/End gap | Flagged | Flagged | PASS |

**19/19 known-issue rows correctly flagged.**

## Negative tests (row known to be clean — should NOT be flagged)

| ID | Dataset | Why it should be clean | Result |
|---|---|---|---|
| TRN0001 | Training_Records | First row, no known issue, unambiguous ISO/YYYY-format date pair | Not in exceptions file — PASS |
| ACC0001 | Access_Control | First row, on-cadence timestamp, matched Badge/Employee pair | Not in exceptions file — PASS |

(Kept intentionally small — the positive-test table above already
implicitly tests every other row in the flagged sheets by omission,
since only the 19 listed IDs appear in their respective exceptions
files.)

## Structural/count tests

| Check | Expected | Actual | Result |
|---|---|---|---|
| Equipment_Events row count after cleaning | 46 raw − 1 exact duplicate = 45 | 45 | PASS |
| Every sheet has exactly 1 exact duplicate | 9/9 sheets | Confirmed via each script's `[duplicates]` changelog line, 1 row each | PASS |
| Total exception rows across all 9 sheets | — | 54 (`cleaned/exception_report.csv`) | Recorded |
| Exception rate | — | 54/405 = 13.3% | Recorded |

## Cross-dataset tests (scripts/03_reconcile.py)

| Check | Expected | Actual | Result |
|---|---|---|---|
| Every equipment code in 5 referencing sheets resolves to the 6-machine master list | Pass | Pass — 0 unresolved codes across all 5 sheets | PASS |
| Access_Control Employee_IDs all present in Training_Records roster | Fail expected (OP9999 is a known bad row) | `{OP9999}` returned as unrostered — matches the single known bad ID | PASS |
| No Operator_Activities time-window overlaps per operator | Pass | 0 overlaps found | PASS |

## Regression caught by re-running before submission
On 2026-08-21, re-running the full pipeline end-to-end ahead of submission
produced a consolidated exception report of **52 rows**, not the 54 this
report and `data_quality_report.md` both document. Tracing it down:
`cleaning_operator_activities.py`'s `build_exceptions()` no longer checked
for negative duration or the Quantity outlier — the checks described in
this document and in `data_quality_report.md` (ACT0013, ACT0020) had been
lost from the script at some point without the reports being caught out of
sync. Fixed by adding `flag_activity_issues()` back into the script
(negative-duration check, and a Quantity-outlier check at 10x the sheet's
median rather than a hardcoded number). Re-ran the full pipeline afterward
— consolidated report is back to 54 rows, with ACT0013 and ACT0020 present
in `operator_activities_exceptions.csv` as documented. This is exactly the
kind of drift that "re-run everything before submitting, don't just trust
that the report matches the code" is meant to catch.

## Known failure / limitation found during testing
Running `clean_training_records.py`/`clean_environmental_readings.py`
standalone (outside the full pipeline) initially failed because an
earlier draft of `utils.py` in this workspace didn't yet include the
cyclic date parser those two scripts' *first* draft depended on. This
was caught by running each script individually rather than only the
full batch, and resolved by adopting the current, self-contained
versions of those two scripts (no longer dependent on a shared cyclic
parser) — noted here as a real bug encountered, not smoothed over.

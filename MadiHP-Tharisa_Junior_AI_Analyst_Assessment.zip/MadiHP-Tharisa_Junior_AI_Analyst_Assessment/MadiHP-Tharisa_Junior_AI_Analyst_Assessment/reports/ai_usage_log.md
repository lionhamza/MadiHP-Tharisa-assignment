# AI Usage Log — Project Signal

## AI Tool Used

I used Claude AI as a support tool while working on Project Signal. I mainly used it for guidance when I was stuck and for helping me think through the overall project architecture.

AI was not responsible for the main project work or the final decisions. I did the data investigation, cleaning, testing, validation, debugging, and decision-making myself.

## What AI Helped Me With

AI mainly helped me with:

* Helping me think through the overall project architecture and how Tasks 1, 2, and 3 could fit together.
* Suggesting possible approaches when I was stuck on a technical problem.
* Explaining some coding concepts and helping me debug specific issues.
* Reviewing parts of my approach and suggesting improvements.
* Helping me structure some of the project documentation.

I used AI as a support tool and did not simply accept its suggestions as final answers.

## What I Did Myself

I was responsible for the main work in the project.

I personally:

* Explored all nine datasets and identified the data-quality issues.
* Investigated inconsistent equipment names and decided how they should be standardized.
* Identified duplicates, missing values, negative values, outliers, incorrect units, typos, and contradictory records.
* Decided which issues could safely be corrected and which ones should only be flagged.
* Built, ran, and debugged the data-cleaning pipeline in VS Code.
* Ran every script against the original dataset.
* Checked the cleaned outputs against the raw Excel data.
* Investigated specific records when something looked incorrect.
* Performed cross-dataset checks.
* Built and tested the main functionality for Task 2 and Task 3.
* Found and fixed bugs that only appeared when running the complete solution.
* Made the final decisions about privacy, fairness, responsible use, and the limitations of the project.
* Wrote and reviewed the final project documentation.

## How I Used AI Suggestions

When AI suggested an approach, I checked whether it actually worked with the project data.

For example, I investigated date formats using patterns and rules found in the dataset, including the 730-day gap between training completion and expiry dates.

I also checked equipment-name mappings against the actual data instead of relying only on spelling similarities.

During my final testing, I found that the exception report produced a different number of flagged records from what my documentation expected. I investigated the issue, found the missing checks, corrected the script, reran the pipeline, and confirmed that the correct records were flagged.

This problem was found through my own end-to-end testing.

## My Approach to Using AI

I treated AI as a tool to support my work, especially when thinking about the project architecture or when I needed help understanding a technical problem.

However, I did the main investigation and implementation myself. I ran the code, tested the results, checked the data, found problems, and made the final decisions.

## What I Learned

The main lesson I learned is that AI can be useful for guidance and support, but it cannot replace my own testing and critical thinking.

The final Project Signal solution is based mainly on my own investigation, implementation, testing, and validation. AI was used as a supporting tool, particularly for guidance on the project architecture and technical problems I encountered.

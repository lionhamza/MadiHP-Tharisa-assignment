# reports/

All my written deliverables:

  README.md              - how to run and use my solution

  data_quality_report.md      - data issues I found, what I fixed, assumptions, and remaining risks

  testing_evidence.md         - tests I ran, expected vs actual results, and failures

  responsible_use_note.md     - privacy, fairness, security, transparency, and limitations

  ai_usage_log.md            - what AI helped me with and what I validated myself

  executive_summary.md       - one-page, non-technical summary

  personal_reflection.md     - what I learned about choosing the responsible answer instead of the easiest one

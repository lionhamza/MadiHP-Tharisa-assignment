# Data-Quality Report — Project Signal

## Scope

I worked with nine sheets, each with 46 raw rows. After removing one exact duplicate from each sheet, I had 405 cleaned rows in total.

I used a separate cleaning script for each sheet. My main rules were:

1. I logged every transformation so I could trace my results back to the code.
2. I only corrected data when I had clear evidence that the correction was correct.
3. If the correct value was uncertain, I flagged it instead of guessing.
4. I never changed the original raw file. All cleaned files were created from `raw/source_data.xlsx`.

## Issues I Found and How I Handled Them

### Duplicate Records

I found one exact duplicate in each sheet. I removed only these exact duplicates and kept all other problematic records in the cleaned data with exception flags.

### Equipment Names

I found different names and spellings for the same equipment, such as `EX 001`, `EXC001`, and `Excavator 1`.

I standardized these names using a master equipment list. I used `Equipment_Events` to help verify the equipment because its meter readings provided evidence that different names referred to the same machine.

### Date Formats

I found dates stored in different formats, including:

* DD/MM/YYYY
* MM/DD/YYYY
* YYYY/MM/DD
* ISO format

Where the date format was clear, I converted it to a consistent format. Where a date could have more than one meaning, I used evidence from the data. For example, in Training Records, I checked whether Completion and Expiry dates followed the expected 730-day gap.

If no interpretation was supported by the data, I flagged the record instead of guessing.

### Typos and Inconsistent Categories

I corrected clear mistakes, including:

* `mecanical` → `Mechanical`
* `Strat` → `Start`
* `hualing` → `Hauling`
* `Saftey` → `Safety`
* `SAFE-1` → `SAFE01`
* `Entry`/`Exit` → `IN`/`OUT`

### Negative and Impossible Values

I found several values that were negative or outside a reasonable range, including:

* Negative durations
* Negative rainfall
* Negative loads
* Availability or utilisation above 100%

I flagged these records rather than changing them without evidence.

### Outliers

I found unusual values such as:

* A very large meter reading
* A dust reading of `9999.0`
* A quantity of `450` where other values were much smaller
* A duration of `14,400` minutes that did not match the Start and End times
* An unknown equipment code, `TRK099`

These records were flagged so that they remain visible to anyone using the cleaned data.

### Units

I handled unit problems differently depending on whether there was enough evidence for a safe conversion.

For example, I converted gallons to litres because there is a known conversion factor.

However, I did not convert loads to tonnes because there was no reliable conversion. I also did not convert the `Meter_Unit` values because the data did not provide enough evidence to confirm what the incorrect values meant.

### Contradictory Records

I found records that looked valid on their own but contradicted other fields.

Examples included:

* `SAF0006` having a Closed Date before the Observation Date
* `SAF0020` having contradictory severity and status information
* `TRN0015` showing `Pass` with a score of `42`
* `TRN0023` having a score of `145`
* `Urgent` being used outside the normal P1/P2/P3 priority scale

I flagged these records instead of deciding what the correct value should be.

### Cross-Dataset Checks

I also checked whether records were consistent across different sheets.

I checked equipment codes, operator identities, and overlapping operator activities.

Most equipment records were consistent after cleaning. However, `OP9999` did not match a real operator in the other datasets, so I kept it flagged instead of automatically changing it.

### Sensitive Information

I identified personal and potentially sensitive information in the data.

Direct personal information such as names, email addresses, and mobile numbers was protected in the cleaned output. Other fields, such as `Home_Zone`, `Contractor_Group`, and `Medical_Fitness_Code`, were kept but flagged as sensitive.

I also redacted an unverified allegation found in a free-text Safety Observation.

## Assumptions

Some checks required assumptions based on patterns in the data:

* Training scores were treated as being on a 0–100 scale.
* A score of 70 or more was treated as a Pass based on the pattern in the dataset.
* The 730-day training validity period and other date patterns were used because they were consistently supported by the unambiguous records.

I used these assumptions to flag possible problems, not to overwrite uncertain values.

## Remaining Risks

Some issues could not be fully resolved:

* The meaning of some `Meter_Unit` values is still uncertain.
* The true identity of `OP9999` is not confirmed.
* Some equipment-name mappings have weaker evidence than others.
* 54 out of 405 cleaned rows, or 13.3%, still have at least one exception flag.

## Trustworthiness

Based on my testing, I consider the cleaned data trustworthy for aggregate and operational analysis, such as identifying trends, comparing equipment, and analysing patterns across shifts.

However, I would not use a single flagged record to make a decision about a specific person or asset without human review.

The main reason is that 351 out of 405 rows have no exception flags, while the remaining records clearly show their unresolved issues. My approach was to keep these flags with the cleaned data instead of hiding or silently removing the problems.

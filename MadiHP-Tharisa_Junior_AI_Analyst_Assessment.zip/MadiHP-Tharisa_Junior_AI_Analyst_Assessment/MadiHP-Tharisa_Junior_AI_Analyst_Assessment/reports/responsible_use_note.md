# Responsible-Use Note — Project Signal

This note explains how I believe the data and tools built for Project Signal should and should not be used. I use the five "reveal" scenarios from the brief as practical examples instead of only discussing responsible use in theory.

## Privacy

I found direct personal information in the `Operator_Activities` dataset, including names, email addresses, and mobile numbers. In my cleaned output, I hash these values and use `Operator_ID` as the working identifier instead. This allows me to connect records belonging to the same person without keeping their contact details visible in the cleaned data.

I also identified `Home_Zone`, `Contractor_Group`, and `Medical_Fitness_Code` as potentially sensitive information. I kept these fields because they may still have legitimate uses, but I flagged them so that they are not used accidentally.

I also found a Safety Observation, `SAF0027`, containing a person's name and an unverified allegation. I redacted this information from the cleaned output because repeating an accusation in an analysis dataset could unfairly affect that person.

## Fairness

**Reveal 4** describes a situation where one shift has more flags than others but also uses older equipment and performs more difficult work.

For me, the easiest answer would be to rank the shifts based only on the number of flags. However, that would not be fair because the equipment and type of work could be the real reason for the difference.

My responsible approach is to show the flag count together with factors such as equipment and task type. I would not use this data to rank or punish workers without considering those differences.

The same applies to `Home_Zone` and `Contractor_Group`. I can use them to check whether a pattern exists, but I should not use them to rank or score individuals.

## Security

**Reveal 5** describes a developer copying production data into a personal AI account because it is faster.

My approach is that sensitive or raw data should not leave the approved project environment. The `raw/` folder contains the original data, while the cleaned data and reports are separated from it.

Although this project uses synthetic data, I followed the same principle I would use with real data: I should not upload personal or operational data into an AI tool unless that use has been approved and the correct data protections are in place.

## Transparency

I made sure that exception flags stay with the cleaned data. Instead of silently removing or changing problematic records, I keep information showing which records contain unresolved issues or assumptions.

**Reveal 3** describes an AI-generated summary that sounds convincing but contradicts the raw data. This is why I believe an answer should be supported by the actual records behind it. A confident explanation is not enough if it cannot be checked against the evidence.

For Task 3, this influenced my decision to build an evidence-based assistant. The assistant should show the records behind its answers instead of simply giving an explanation that cannot be verified.

## Human Oversight

I did not automatically correct data when there was no clear evidence of the correct value. For example, I flagged ambiguous or contradictory records such as `OP9999`, `TRN0008`, `SAF0006`, and `SAF0020` instead of guessing the correct answer.

**Reveal 2** describes pressure to deploy a system without a governance review. The easiest answer would be to deploy immediately because of the deadline. However, my responsible approach would be to keep human review for any output that could affect a specific person.

If someone decides to override that safeguard, the decision and the risk should be recorded instead of being ignored.

**Reveal 1** describes joining an HR dataset containing information such as age, medical restrictions, disciplinary history, and absence history.

I would not automatically join all of this information simply because it could improve accuracy. Before using additional personal information, I would first ask what specific decision it is needed for. If only medical fitness information is necessary, then disciplinary or absence history should not be included. Adding unnecessary personal data creates additional privacy and fairness risks.

## Limitations

There are still limitations in my solution:

* `Meter_Unit` in `Equipment_Events` contains both hours and minutes, but there is not enough evidence to safely convert the values. These records remain flagged.
* The true identity of `OP9999` is not confirmed. Although the available evidence suggests a possible match, I did not automatically change it.
* Some cleaned records still contain exception flags, meaning they should be used with care depending on the type of analysis.
* The dataset is synthetic and covers a short period at one fictional site. My findings should not automatically be assumed to apply to real operations or a larger workforce.

## My Main Reflection

The main lesson for me was the difference between the easiest answer and the responsible answer.

The easiest answer would often be to automatically fix unusual values, rank people based on incomplete data, use more personal information to improve accuracy, or trust an AI-generated explanation because it sounds correct.

The responsible answer requires more work. It means checking the evidence, keeping uncertainty visible, protecting sensitive information, considering fairness, involving human review, and clearly documenting limitations.

That is the approach I tried to follow throughout Project Signal.

# Task 3 — AI Assistant for Operational Knowledge Retention

This project is a Streamlit-based operational knowledge assistant developed for AI Assistent. The application allows users to ask questions about the available mining operations data, including equipment, downtime, safety, training, maintenance, shift performance, and data-quality issues.

The assistant works with the cleaned datasets produced in Task 1. Rather than giving the language model unrestricted access to the underlying CSV files, the application uses a set of approved Python functions in `tools.py` to retrieve the relevant information.

The returned records can be reviewed together with their record IDs, making it possible to trace the information used in an answer.

## Running the application

From the project folder, navigate to the application directory:

```bash
cd Project_Signal/app/ai_assistant_streamlit
```

Install the required dependencies:

```bash
pip install -r requirements.txt
```

Then start the Streamlit application:

```bash
streamlit run app.py
```

Streamlit will display a local address in the terminal, usually:

`http://localhost:8501`

Open the address in your browser to use the application.

## API key setup

The Anthropic API key is stored as an environment variable and is not entered through the Streamlit interface.

Create a `.env` file inside the `ai_assistant_streamlit` folder:

```env
ANTHROPIC_API_KEY=your_api_key_here
```

The application loads the key from the environment when it starts.

The `.env` file should not be committed to Git. Make sure it is included in `.gitignore`:

```gitignore
.env
__pycache__/
*.pyc
```

If an API key is not configured, the application can still run using the offline fallback.

## Offline fallback

The offline mode provides a rule-based fallback when the live AI service is unavailable or when no API key has been configured.

It recognises questions related to areas such as:

* Downtime and delays
* Safety observations
* Training and certification expiry
* Maintenance notifications
* Shift performance
* Equipment status
* Data-quality issues

The fallback uses the same data-querying functions in `tools.py`, but does not make an external API call.

This means the application can still demonstrate its main data access and evidence-tracing functionality when the live service is unavailable.

## Project structure

* `app.py` — Contains the Streamlit interface, including the chat interface, evidence view, audit log, and project information.

* `llm_client.py` — Handles communication with the language model, tool calling, the offline fallback, and refusal rules.

* `tools.py` — Contains the approved functions used to query the cleaned datasets.

* `requirements.txt` — Lists the Python packages required to run the application.

* `.env` — Stores local environment variables such as the API key. This file should not be committed to Git.

## Data source

The application uses the cleaned datasets produced during Task 1.

The main data is read from:

```text
../../cleaned/
```

It also uses the Task 1 exception report:

```text
../../cleaned/exception_report.csv
```

The application does not query the original files in the `raw/` folder.

## How the assistant works

The application follows the flow below:

```text
User question
      ↓
llm_client.py
      ↓
Tool selection
      ↓
tools.py
      ↓
Cleaned Task 1 data
      ↓
Relevant records returned
      ↓
Answer with supporting record IDs
```

When a question requires operational data, the assistant retrieves information through the approved functions in `tools.py`. These functions return only the records relevant to the question, together with record IDs and any available data-quality notes.

The application keeps a record of each question, the tools used, the returned evidence, and the final answer for the current session. This information can also be reviewed through the audit log and downloaded as a JSON file.

## Scope and limitations

The assistant is designed to answer descriptive and diagnostic questions based on the available operational data.

Its answers are limited by the information contained in the cleaned Task 1 datasets. Where relevant, known data-quality issues or caveats are included with the returned evidence.

The application does not make disciplinary, staffing, allocation, or deployment decisions about people or crews. These decisions require human judgement and additional operational context that may not be available in the dataset.

The project is intended as a prototype for exploring how operational knowledge can be queried while maintaining clear boundaries around data access, evidence, and decision-making.

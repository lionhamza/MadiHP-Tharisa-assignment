# app.py — Project Signal / Task 3
"""
This is the main Streamlit application for Project Signal.

I built this application to give users a simple way to ask questions
about the operational data without exposing the API key or the raw
CSV files to the user.

The main things this application does are:

1. Takes a question from the user.
2. Sends the question to llm_client.py.
3. Lets the LLM get information through the approved functions in tools.py.
4. Keeps a record of the questions, answers, tools used and evidence.
5. Lets the user view the record IDs and data that were used for an answer.
6. Falls back to an offline rule-based response if the AI service is not
   available.

I also made sure the API key stays on the backend and is loaded from an
environment variable instead of being entered into the application.
"""

import datetime
import json
import os

import streamlit as st

from dotenv import load_dotenv
from llm_client import ask


# ---------------------------------------------------------------------------
# I load the environment variables here so the backend can access things
# like the Anthropic API key without putting the key directly in the code.
# ---------------------------------------------------------------------------

load_dotenv()


# ---------------------------------------------------------------------------
# I set up the basic Streamlit page settings here.
# ---------------------------------------------------------------------------

st.set_page_config(
    page_title="Project Signal — Ops Knowledge Assistant",
    page_icon="⛏️",
    layout="wide",
)


# ---------------------------------------------------------------------------
# I use Streamlit session state to keep the conversation while the user
# is using the application.
# ---------------------------------------------------------------------------

if "history" not in st.session_state:

    st.session_state.history = []



# Sidebar.


with st.sidebar:

    st.title(
        "⛏️ Project Signal"
    )

    st.caption(
        "Operational Knowledge Assistant"
    )

    st.markdown(
        "---"
    )

    # I don't show the API key anywhere in the application.
    # I only check whether the backend has been configured correctly.

    if os.getenv(
        "ANTHROPIC_API_KEY"
    ):

        st.success(
            "🟢 AI service ready"
        )

        st.caption(
            "The AI service is securely configured on the backend. "
            "No API key is required from users."
        )

    else:

        st.warning(
            "🟡 Offline mode"
        )

        st.caption(
            "No backend API key is currently configured. "
            "The assistant will use the transparent rule-based "
            "fallback."
        )

    st.markdown(
        "---"
    )

    st.subheader(
        "Example questions"
    )

    examples = [
        "Which assets had unusually high downtime?",
        "What data-quality issues could affect this conclusion?",
        "Show me open safety observations",
        "What training is expiring soon?",
        "Show me recent equipment events",
        "What maintenance notifications are available?",
        "Should we discipline the operator with the most downtime?",
    ]

    for example in examples:

        if st.button(
            example,
            use_container_width=True,
        ):

            st.session_state[
                "_pending_question"
            ] = example


# ---------------------------------------------------------------------------
# I split the application into three tabs so the main chat, audit information
# and project explanation are kept separate.
# ---------------------------------------------------------------------------

tab_chat, tab_audit, tab_about = st.tabs(
    [
        "💬 Chat",
        "📋 Audit Log",
        "ℹ️ About / Limitations",
    ]
)


# ===========================================================================
# CHAT TAB
# ===========================================================================

with tab_chat:

    st.title(
        "Project Signal"
    )

    st.subheader(
        "Operational Knowledge Assistant"
    )

    st.caption(
        "Ask questions about equipment, downtime, safety, training, "
        "maintenance, shifts, and data quality. "
        "Answers are grounded in approved data tool calls."
    )

    # -----------------------------------------------------------------------
    # If the user clicked one of the example questions, I get that question
    # from the session state so it can be used as the next question.
    # -----------------------------------------------------------------------

    pending_question = st.session_state.pop(
        "_pending_question",
        None,
    )

    # -----------------------------------------------------------------------
    # This is where the user can enter a normal question.
    # -----------------------------------------------------------------------

    question = st.chat_input(
        "Ask about equipment, downtime, safety, training, maintenance, shifts..."
    )

    # If an example was selected, I use it as the question unless the user
    # has already typed their own question.

    if pending_question and not question:

        question = pending_question


    # -----------------------------------------------------------------------
    # I go through the previous questions and answers stored in the session
    # and display them in the chat.
    # -----------------------------------------------------------------------

    for turn in st.session_state.history:

        # I display the question that the user originally asked.

        with st.chat_message(
            "user"
        ):

            st.write(
                turn["question"]
            )


        # I display the answer that was returned by the assistant.

        with st.chat_message(
            "assistant"
        ):

            mode_label = {

                "live": (
                    "🟢 Live AI answer — grounded in approved tool calls"
                ),

                "offline": (
                    "🟡 Offline rule-based answer — no LLM call"
                ),

                "offline-after-error": (
                    "🟡 Offline fallback — live AI service unavailable"
                ),

                "refused": (
                    "🔴 Declined — outside the assistant's scope"
                ),

                "pending": (
                    "⏳ Processing"
                ),

            }.get(
                turn["mode"],
                turn["mode"],
            )

            st.caption(
                mode_label
            )

            st.write(
                turn["answer"]
            )


            # ----------------------------------------------------------------
            # I show the evidence used for the answer inside an expandable
            # section so the main chat does not become too crowded.
            # ----------------------------------------------------------------

            if turn["record_ids"]:

                with st.expander(
                    f"Evidence — "
                    f"{len(turn['record_ids'])} record(s)"
                ):

                    st.markdown(
                        "**Record IDs used in this answer:**"
                    )

                    st.code(
                        ", ".join(
                            turn["record_ids"]
                        )
                    )

                    # I also display the rows returned by the tools so the
                    # user can see what information was used to produce
                    # the answer.

                    for call in turn[
                        "tool_calls"
                    ]:

                        tool_name = call.get(
                            "tool",
                            "Unknown tool",
                        )

                        tool_input = call.get(
                            "input",
                            {},
                        )

                        st.markdown(
                            f"### {tool_name}"
                        )

                        st.caption(
                            f"Input: {tool_input}"
                        )

                        result = call.get(
                            "result",
                            {},
                        )

                        records = result.get(
                            "records",
                            [],
                        )

                        if records:

                            st.dataframe(
                                records,
                                use_container_width=True,
                            )

                        else:

                            note = result.get(
                                "note",
                                ""
                            )

                            if note:

                                st.caption(
                                    note
                                )


# ---------------------------------------------------------------------------
# I process a new question here after the user submits it.
# ---------------------------------------------------------------------------

    if question:

        # I first add a temporary entry to the chat so the user's question
        # is shown while the application is getting the actual answer.

        st.session_state.history.append(
            {
                "question": question,
                "answer": "Checking the available evidence...",
                "tool_calls": [],
                "record_ids": [],
                "mode": "pending",
                "ts": (
                    datetime.datetime.now()
                    .isoformat()
                ),
            }
        )


        # -------------------------------------------------------------------
        # I send the question to my assistant function.
        #
        # I don't pass the API key here because the key is handled by the
        # backend through the environment variable.
        # -------------------------------------------------------------------

        with st.spinner(
            "Checking the operational data..."
        ):

            result = ask(
                question
            )


        # I update the temporary entry with the actual response and evidence.

        st.session_state.history[-1].update(
            result
        )


        # I rerun the application so the completed answer appears immediately.

        st.rerun()


# ===========================================================================
# AUDIT LOG TAB
# ===========================================================================

with tab_audit:

    st.header(
        "Audit Log"
    )

    st.caption(
        "Every question, tool call, evidence record ID, and answer "
        "from the current session is recorded here for review."
    )

    if not st.session_state.history:

        st.info(
            "No questions have been asked in this session yet."
        )


    # -----------------------------------------------------------------------
    # I go through each conversation entry and display the information that
    # was recorded during that interaction.
    # -----------------------------------------------------------------------

    for index, turn in enumerate(
        st.session_state.history,
        start=1,
    ):

        timestamp = turn.get(
            "ts",
            ""
        )

        mode = turn.get(
            "mode",
            ""
        )

        st.markdown(
            f"### {index}. "
            f"{timestamp} "
            f"— {mode}"
        )

        st.markdown(
            f"**Question:** "
            f"{turn['question']}"
        )


        # I collect the names of the tools that were used for this answer
        # so it is easy to see how the result was produced.

        tool_names = [
            call.get(
                "tool",
                "Unknown"
            )
            for call in turn[
                "tool_calls"
            ]
        ]

        if tool_names:

            st.markdown(
                f"**Tools called:** "
                f"{', '.join(tool_names)}"
            )

        else:

            st.markdown(
                "**Tools called:** None"
            )


        # I display the record IDs that were used as evidence for the answer.

        if turn["record_ids"]:

            st.markdown(
                "**Evidence record IDs:**"
            )

            st.code(
                ", ".join(
                    turn["record_ids"]
                )
            )

        else:

            st.markdown(
                "**Evidence record IDs:** None"
            )


        # I only show the first 500 characters here so the audit page does
        # not become too long when an answer contains a lot of text.

        answer = turn.get(
            "answer",
            ""
        )

        preview = answer[:500]

        if len(answer) > 500:

            preview += "..."


        st.markdown(
            f"**Answer preview:**\n\n"
            f"{preview}"
        )

        st.markdown(
            "---"
        )


    # -----------------------------------------------------------------------
    # I give the user the option to download the audit information as JSON.
    # -----------------------------------------------------------------------

    if st.session_state.history:

        log_text = json.dumps(
            st.session_state.history,
            indent=2,
            default=str,
        )

        st.download_button(
            label=(
                "Download Full Audit Log (JSON)"
            ),
            data=log_text,
            file_name=(
                "project_signal_audit_log.json"
            ),
            mime=(
                "application/json"
            ),
        )


# ===========================================================================
# ABOUT TAB
# ===========================================================================

with tab_about:

    st.header(
        "About This Assistant"
    )


    st.subheader(
        "Architecture"
    )

    st.markdown(
        """
I designed the assistant so that the language model does not get direct
access to the raw CSV files.

Instead, the model can only get information by calling the approved
functions that I created in `tools.py`.

These functions query the cleaned Task 1 datasets and return a limited
amount of structured information, such as:

- Records
- Record IDs
- Data-quality caveats
- Query notes

The LLM's main job is to decide which approved tools are useful for the
question and then explain the evidence returned by those tools.
"""
    )


    st.subheader(
        "API Key Security"
    )

    st.markdown(
        """
I keep the Anthropic API key on the backend using the
`ANTHROPIC_API_KEY` environment variable.

This means the key is:

- Not entered by the user
- Not displayed in the Streamlit interface
- Not stored in Streamlit session state
- Not included in the audit log
- Not passed from the browser as a chat parameter

The user only interacts with the assistant and does not need to know or
handle the API key.
"""
    )


    st.subheader(
        "Governance Controls"
    )

    st.markdown(
        """
### Evidence grounding

I made the assistant use approved tool calls when it needs operational
information. The record IDs are saved so the evidence behind an answer
can be checked.

### Data-quality caveats

The Task 1 data contains different quality issues and flags. I return
these with the relevant records so they can be considered when looking
at an answer.

### PII protection

I mask identity-related fields before the records are returned through
the tools.

### Refusal boundary

I don't allow the assistant to make disciplinary, allocation, or
deployment recommendations about named people or crews.

I treated these as decisions that should stay with a human because they
can require information and context that is not available in the
dataset.

### Audit trail

I keep the questions, tool calls, evidence record IDs, and answers in
the current Streamlit session. The user can also download this
information as a JSON file.

### Transparent fallback

If the live AI service is unavailable, the application switches to a
rule-based offline mode. I made this visible to the user so that an
offline response is not confused with an answer generated by the LLM.
"""
    )


    st.subheader(
        "Mapping to the Project Brief"
    )

    st.markdown(
        """
### Reveal 1 — Personal information

I mask identity-related fields and don't combine the operational data
with an HR-style identity dataset.

### Reveal 2 — Pressure to bypass governance

I put the refusal rules and evidence checks into the application's
execution path instead of depending only on the instructions given to
the model.

### Reveal 3 — Confident but incorrect AI output

I designed the application so operational claims can be checked against
the evidence returned by the approved tools and the related record IDs.

This is better than relying only on what the model says in its final
answer.

### Reveal 4 — Potentially unfair impact on a shift or crew

The assistant can explain what the available data shows, but it does
not automatically turn operational measurements into a recommendation
about a person or crew.

I also recognise that someone reviewing the result may have information
that is not contained in the dataset, such as equipment age, operating
conditions, or other environmental factors.
"""
    )


    st.subheader(
        "Known Limitations"
    )

    st.markdown(
        """
- The offline fallback only understands a limited number of question types.
- The live tool-calling loop has a fixed maximum number of iterations.
- The tool queries were designed around the prototype dataset and would
  need further work before being used with much larger datasets.
- This is a prototype and should not be used as an autonomous system for
  making operational decisions.
"""
    )

# llm_client.py — Project Signal / Task 3

"""
This file handles the communication between Project Signal and the AI model.

I keep the Anthropic API key on the backend instead of asking the user to
enter it in the Streamlit application.

There are two ways the application can run:

1. Live mode
   If the API key is available, I use Anthropic's tool-calling functionality
   to answer the user's question using the approved tools.

2. Offline mode
   If the API key is not available, I use a basic rule-based fallback
   instead of making the application fail.

One of the main things I wanted to achieve with this project is that the
LLM should not have direct access to the raw CSV files.

Instead, the model can only get operational information through the
functions I created in tools.py. This also makes it easier to keep track
of what information was used to produce an answer.

The tools return structured information such as:

- records
- record IDs
- data-quality caveats
- notes

The model should only use the information returned by these tools and
should not make up site-specific facts.
"""

from __future__ import annotations

import json
import os

from dotenv import load_dotenv

from tools import TOOL_REGISTRY


# ---------------------------------------------------------------------------
# I load the environment variables here so that the API key can be stored
# outside the actual source code when I run the application locally.
# ---------------------------------------------------------------------------

load_dotenv()


def get_api_key() -> str | None:
    """
    Get the Anthropic API key from the backend environment.

    I keep this separate in a function so that the rest of the application
    does not need to know where the API key is stored.
    """
    return os.getenv("ANTHROPIC_API_KEY")


# ---------------------------------------------------------------------------
# Refusal boundary.
#
# I use this list to identify questions where the assistant should not make
# a decision about a person, crew, allocation, or disciplinary action.
# ---------------------------------------------------------------------------

REFUSAL_KEYWORDS = [
    "should we fire",
    "should we discipline",
    "discipline",
    "terminate",
    "dismiss",
    "who should be blamed",
    "whose fault",
    "punish",
    "should we allocate",
    "who should be allocated",
    "who should get",
    "deploy the solution",
    "should we deploy",
    "recommend action against",
    "who is responsible for the failure",
    "sack",
    "suspend",
]


# This is the response I return when a question crosses the refusal boundary.

REFUSAL_MESSAGE = (
    "I can show you what the data says, including downtime, safety flags, "
    "training status, maintenance records, and data-quality issues. "
    "However, I will not make a disciplinary, allocation, or deployment "
    "recommendation about a named person or crew. That decision requires "
    "human review, context, and accountability. "
    "For example, a shift that appears to perform poorly in the available "
    "data may also be operating older equipment or working under conditions "
    "that are not represented in these datasets. "
    "You can ask me for the underlying evidence instead, such as: "
    "'Show me the downtime and safety records for this equipment or crew.'"
)


def is_refusal_worthy(question: str) -> bool:
    """
    Check if the question is asking the assistant to make a decision that
    should be left to a human.

    I use simple keyword matching here rather than asking the LLM to decide
    whether something should be refused.
    """
    q = question.lower()

    return any(
        keyword in q
        for keyword in REFUSAL_KEYWORDS
    )


# ---------------------------------------------------------------------------
# Tool schemas.
#
# These are the tools that I allow the LLM to use when it needs information
# from the operational datasets.
#
# The important part here is that the LLM does not get the raw CSV files.
# It only gets the results returned by these approved functions.
# ---------------------------------------------------------------------------

TOOL_SCHEMAS = [
    {
        "name": "get_downtime_by_equipment",
        "description": (
            "Total delay or downtime minutes per equipment asset. "
            "Optionally filter to one asset."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "equipment_name": {
                    "type": "string",
                    "description": (
                        "Asset name or prefix, for example TRK-002. "
                        "Omit for a ranking across all assets."
                    ),
                },
                "top_n": {
                    "type": "integer",
                    "description": (
                        "How many top assets to return when not filtering "
                        "by equipment name. Default is 5."
                    ),
                },
            },
        },
    },
    {
        "name": "get_safety_observations",
        "description": (
            "Safety observation records, optionally filtered by severity, "
            "status, or equipment."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "severity": {
                    "type": "string",
                    "description": "For example: Low, Medium, High",
                },
                "status": {
                    "type": "string",
                    "description": (
                        "For example: Open, In Review, Closed"
                    ),
                },
                "equipment_name": {
                    "type": "string",
                },
            },
        },
    },
    {
        "name": "get_training_expiry",
        "description": (
            "Training or certification records, optionally filtered by "
            "operator ID or an expiry cutoff date."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "operator_id": {
                    "type": "string",
                },
                "expiring_before": {
                    "type": "string",
                    "description": "YYYY-MM-DD cutoff date",
                },
            },
        },
    },
    {
        "name": "get_equipment_status",
        "description": (
            "Most recent equipment events including start, stop, idle, "
            "and status records. Optionally filter by equipment."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "equipment_name": {
                    "type": "string",
                },
            },
        },
    },
    {
        "name": "get_maintenance_notifications",
        "description": (
            "Maintenance notification records, optionally filtered by "
            "equipment or priority such as P1, P2, or P3."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "equipment_name": {
                    "type": "string",
                },
                "priority": {
                    "type": "string",
                },
            },
        },
    },
    {
        "name": "get_shift_performance",
        "description": (
            "Shift performance records including hours, loads, tonnes, "
            "availability, and utilisation. Optionally filter by "
            "equipment or crew."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "equipment_name": {
                    "type": "string",
                },
                "crew": {
                    "type": "string",
                },
            },
        },
    },
    {
        "name": "get_data_quality_summary",
        "description": (
            "Counts of known data-quality exceptions per dataset from "
            "the Task 1 exception report."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "dataset": {
                    "type": "string",
                },
            },
        },
    },
]


# ---------------------------------------------------------------------------
# This is the main instruction I give to the LLM.
#
# I use it to explain what the assistant is allowed to do and, more
# importantly, what it should not do.
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """
You are an operational knowledge assistant for a mining site called
Project Signal.

You answer questions ONLY using the approved tools provided to you.

You have no direct access to raw CSV files, databases, external systems,
or general knowledge about this specific mining site's operations.

Rules:

1. Never invent site-specific facts, numbers, record IDs, names, or events.

2. Every factual claim about the site's operational data must come from
   information returned by one or more approved tool calls.

3. Cite the specific record IDs returned by the tools whenever you make
   factual claims.

4. If a tool returns no matching records, clearly state that no matching
   data was found. Do not guess or fill gaps.

5. If returned records include data-quality caveats, anomalies, mismatches,
   or flags, explicitly mention those caveats in your answer.

6. Never reveal or attempt to infer a person's real name, contact details,
   badge ID, or other masked identity information.

7. Do not make disciplinary, allocation, or deployment recommendations
   about named people or crews. These decisions require human review and
   accountability.

8. If the available tool results are insufficient to answer confidently,
   explain what information is missing rather than guessing.

9. Keep answers concise but useful. Explain the evidence and identify any
   important limitations or caveats.

10. Do not claim that you inspected data unless you actually received it
    through a tool call.
"""


# ---------------------------------------------------------------------------
# Live mode.
#
# This is where I make the actual Anthropic API call and handle the
# tool-calling process.
# ---------------------------------------------------------------------------

def ask_claude(
    question: str,
    model: str = "claude-sonnet-4-6",
) -> dict:
    """
    Run the Anthropic tool-calling loop.

    I get the API key from the backend environment and then let the model
    request information through the tools defined above.

    I also keep a log of the tools that were called and the record IDs
    returned by them so that the application can show the evidence later.
    """

    import anthropic

    api_key = get_api_key()

    if not api_key:
        raise RuntimeError(
            "ANTHROPIC_API_KEY is not configured."
        )

    client = anthropic.Anthropic(
        api_key=api_key
    )

    messages = [
        {
            "role": "user",
            "content": question,
        }
    ]

    # I keep these so that app.py can display what evidence was used.

    tool_calls_log = []
    all_record_ids = []

    # I put a limit on the number of tool-calling rounds so the application
    # does not keep calling tools indefinitely.
    for _ in range(5):

        response = client.messages.create(
            model=model,
            max_tokens=1000,
            system=SYSTEM_PROMPT,
            tools=TOOL_SCHEMAS,
            messages=messages,
        )

        # ---------------------------------------------------------------
        # If the model is finished with its tool calls, I return the
        # final answer.
        # ---------------------------------------------------------------

        if response.stop_reason != "tool_use":

            final_text = "".join(
                block.text
                for block in response.content
                if block.type == "text"
            )

            return {
                "answer": final_text,
                "tool_calls": tool_calls_log,
                "record_ids": sorted(
                    set(all_record_ids)
                ),
                "mode": "live",
            }

        # ---------------------------------------------------------------
        # The model wants to use one or more tools.
        #
        # I first save its response and then run the requested tools.
        # ---------------------------------------------------------------

        messages.append(
            {
                "role": "assistant",
                "content": response.content,
            }
        )

        tool_results = []

        for block in response.content:

            if block.type != "tool_use":
                continue

            # I look up the requested function from my approved registry.
            # This prevents the model from calling arbitrary Python code.

            function = TOOL_REGISTRY.get(
                block.name
            )

            if function is None:

                result = {
                    "error": (
                        f"Unknown or unauthorised tool: "
                        f"{block.name}"
                    )
                }

            else:

                try:

                    # Run the approved function with the arguments requested
                    # by the model.

                    result = function(
                        **(block.input or {})
                    )

                except Exception:

                    # I don't send the actual backend error back to the user.
                    # A generic message is safer and easier to understand.

                    result = {
                        "error": (
                            "The requested data query could not "
                            "be completed."
                        )
                    }

            # Save the tool call because I want it available in the audit log.

            tool_calls_log.append(
                {
                    "tool": block.name,
                    "input": block.input,
                    "result": result,
                }
            )

            # Collect all record IDs returned by the tools.
            # These are later used as the evidence for the answer.

            all_record_ids.extend(
                result.get(
                    "record_ids",
                    []
                )
            )

            # Send the structured result back to Claude so it can use the
            # returned information to continue answering the question.

            tool_results.append(
                {
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": json.dumps(
                        result,
                        default=str,
                    )[:8000],
                }
            )

        messages.append(
            {
                "role": "user",
                "content": tool_results,
            }
        )

    # -------------------------------------------------------------------
    # If the maximum number of tool calls is reached, I stop the process
    # instead of continuing forever.
    # -------------------------------------------------------------------

    return {
        "answer": (
            "I was not able to complete the analysis within the allowed "
            "tool-call limit. Please try a more specific question."
        ),
        "tool_calls": tool_calls_log,
        "record_ids": sorted(
            set(all_record_ids)
        ),
        "mode": "live",
    }


# ---------------------------------------------------------------------------
# Offline mode.
#
# I added this as a fallback so the application can still demonstrate the
# governance and data-query logic when the AI service is not available.
# ---------------------------------------------------------------------------

def ask_offline(question: str) -> dict:
    """
    Use simple rules to decide which approved tool should be called.

    This is intentionally basic. It is clearly labelled as offline mode
    and is not presented as if an LLM generated the answer.
    """

    q = question.lower()

    tool_calls_log = []

    # I use this small helper so that every tool call is logged in the
    # same way as it is in the live mode.

    def run(name: str, **kwargs) -> dict:

        result = TOOL_REGISTRY[name](
            **kwargs
        )

        tool_calls_log.append(
            {
                "tool": name,
                "input": kwargs,
                "result": result,
            }
        )

        return result

    # -------------------------------------------------------------------
    # Downtime questions.
    # -------------------------------------------------------------------

    if (
        "downtime" in q
        or "delay" in q
    ):

        result = run(
            "get_downtime_by_equipment"
        )

        summary = result.get(
            "summary_totals_minutes",
            {}
        )

        if summary:

            lines = [
                f"- {equipment}: {minutes:.0f} min"
                for equipment, minutes
                in summary.items()
            ]

            answer = (
                "Total downtime minutes by equipment "
                "(top assets):\n\n"
                + "\n".join(lines)
            )

        else:

            answer = (
                result.get("note")
                or "No downtime data found."
            )

    # -------------------------------------------------------------------
    # Safety questions.
    # -------------------------------------------------------------------

    elif "safety" in q:

        status_filter = None

        if "open" in q:
            status_filter = "Open"

        elif "closed" in q:
            status_filter = "Closed"

        result = run(
            "get_safety_observations",
            status=status_filter,
        )

        records = result.get(
            "records",
            []
        )

        if records:

            answer = (
                f"Found {len(records)} safety "
                f"observation record(s)."
            )

        else:

            answer = (
                result.get("note")
                or "No matching safety observations found."
            )

    # -------------------------------------------------------------------
    # Training and certification questions.
    # -------------------------------------------------------------------

    elif (
        "training" in q
        or "expir" in q
        or "certif" in q
    ):

        result = run(
            "get_training_expiry"
        )

        records = result.get(
            "records",
            []
        )

        if records:

            answer = (
                f"Found {len(records)} training "
                f"or certification record(s)."
            )

        else:

            answer = (
                result.get("note")
                or "No matching training records found."
            )

    # -------------------------------------------------------------------
    # Maintenance questions.
    # -------------------------------------------------------------------

    elif (
        "maintenance" in q
        or "notification" in q
    ):

        result = run(
            "get_maintenance_notifications"
        )

        records = result.get(
            "records",
            []
        )

        if records:

            answer = (
                f"Found {len(records)} maintenance "
                f"notification record(s)."
            )

        else:

            answer = (
                result.get("note")
                or "No matching maintenance records found."
            )

    # -------------------------------------------------------------------
    # Shift performance questions.
    # -------------------------------------------------------------------

    elif (
        "shift" in q
        or "utilisation" in q
        or "utilization" in q
        or "availability" in q
    ):

        result = run(
            "get_shift_performance"
        )

        records = result.get(
            "records",
            []
        )

        if records:

            answer = (
                f"Found {len(records)} shift "
                f"performance record(s)."
            )

        else:

            answer = (
                result.get("note")
                or "No matching shift performance records found."
            )

    # -------------------------------------------------------------------
    # Equipment status questions.
    # -------------------------------------------------------------------

    elif (
        "equipment" in q
        or "status" in q
        or "event" in q
    ):

        result = run(
            "get_equipment_status"
        )

        records = result.get(
            "records",
            []
        )

        if records:

            answer = (
                f"Found {len(records)} equipment "
                f"event record(s)."
            )

        else:

            answer = (
                result.get("note")
                or "No equipment records found."
            )

    # -------------------------------------------------------------------
    # Data-quality questions.
    # -------------------------------------------------------------------

    elif (
        "data quality" in q
        or "data-quality" in q
        or "exception" in q
        or "anomaly" in q
    ):

        result = run(
            "get_data_quality_summary"
        )

        summary = result.get(
            "summary_counts",
            {}
        )

        if summary:

            answer = (
                "Exception counts by dataset:\n\n"
                + "\n".join(
                    f"- {dataset}: {count}"
                    for dataset, count
                    in summary.items()
                )
            )

        else:

            answer = (
                result.get("note")
                or "No data-quality summary was found."
            )

    # -------------------------------------------------------------------
    # If I don't recognise the question, I still return a useful
    # data-quality summary instead of pretending I understood it.
    # -------------------------------------------------------------------

    else:

        result = run(
            "get_data_quality_summary"
        )

        answer = (
            "Offline mode is a transparent rule-based fallback and "
            "currently recognises questions about downtime, safety, "
            "training, maintenance, equipment status, shift performance, "
            "or data quality.\n\n"
            "General data-quality summary:\n\n"
            + "\n".join(
                f"- {dataset}: {count}"
                for dataset, count
                in result.get(
                    "summary_counts",
                    {}
                ).items()
            )
        )

    # -------------------------------------------------------------------
    # I add any data-quality warnings returned by the tool so that the
    # user can see possible issues with the information being used.
    # -------------------------------------------------------------------

    caveats = result.get(
        "caveats",
        []
    )

    if caveats:

        answer += (
            "\n\nData-quality caveats:\n\n"
            + "\n".join(
                f"- {caveat}"
                for caveat in caveats
            )
        )

    return {
        "answer": answer,
        "tool_calls": tool_calls_log,
        "record_ids": result.get(
            "record_ids",
            []
        ),
        "mode": "offline",
    }


# ---------------------------------------------------------------------------
# Main entry point.
#
# app.py calls this function whenever the user asks a question.
# ---------------------------------------------------------------------------

def ask(question: str) -> dict:
    """
    Main function used by app.py.

    The only thing passed into this function is the user's question.
    The API key is handled separately on the backend.
    """

    # -------------------------------------------------------------------
    # I check the refusal boundary before sending anything to the LLM.
    #
    # This means that some decisions are blocked by the application
    # itself instead of relying only on the model's instructions.
    # -------------------------------------------------------------------

    if is_refusal_worthy(question):

        return {
            "answer": REFUSAL_MESSAGE,
            "tool_calls": [],
            "record_ids": [],
            "mode": "refused",
        }

    # -------------------------------------------------------------------
    # Check whether an API key is available.
    # -------------------------------------------------------------------

    api_key = get_api_key()

    # -------------------------------------------------------------------
    # If the API key exists, I try to use the live AI service.
    # -------------------------------------------------------------------

    if api_key:

        try:

            return ask_claude(
                question
            )

        except Exception:

            # If the live service fails, I don't expose the actual error
            # to the user. Instead, I switch to the offline fallback.

            fallback = ask_offline(
                question
            )

            fallback["answer"] = (
                "The live AI service is currently unavailable. "
                "The application has switched to the transparent "
                "rule-based fallback.\n\n"
                + fallback["answer"]
            )

            fallback["mode"] = (
                "offline-after-error"
            )

            return fallback

    # -------------------------------------------------------------------
    # If there is no API key configured, I go directly to offline mode.
    # -------------------------------------------------------------------

    return ask_offline(
        question
    )
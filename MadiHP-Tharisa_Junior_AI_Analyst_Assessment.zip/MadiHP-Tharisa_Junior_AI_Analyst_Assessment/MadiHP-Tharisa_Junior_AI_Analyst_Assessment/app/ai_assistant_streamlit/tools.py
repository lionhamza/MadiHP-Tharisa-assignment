# tools.py — Project Signal / Task 3
"""

This file contains the functions that I allow the LLM to use when it
needs information from the cleaned Task 1 datasets.

I did not want the LLM to have direct access to the raw CSV files.
Instead, it can only get information by calling one of the functions
below.

Each function uses pandas to query the cleaned data and returns a
structured result containing the records, record IDs, and any
data-quality issues that were found.

The general result returned by these functions looks like this:

{
    "records": [ {...row...}, ... ],
    "record_ids": [ "SAF0001", ... ],
    "caveats": [
        "2 of these records have unresolved duration conflicts"
    ],
    "note": "Additional information, such as no matching records found"
}

I also mask identity-related fields before returning the records so
that the assistant does not expose personal information.
"""

from __future__ import annotations
import os
import pandas as pd


# ---------------------------------------------------------------------------
# I keep the location of the cleaned Task 1 data here so that all the
# functions can load the datasets from the same place.
# ---------------------------------------------------------------------------

DATA_DIR = os.path.join(
    os.path.dirname(__file__),
    "..",
    "..",
    "cleaned",
)

DATA_DIR = os.path.abspath(
    DATA_DIR
)


# ---------------------------------------------------------------------------
# These are the columns that I don't want the tools to return directly.
#
# Some of these fields could identify a person, so I replace them with
# "[masked]" before the data is passed back to the assistant.
# ---------------------------------------------------------------------------

PII_COLUMNS = {
    "Employee_Name",
    "Operator_Name",
    "Reported_By",
    "Approved_By",
    "Email",
    "Mobile_Number",
    "Badge_ID",
}


# ---------------------------------------------------------------------------
# These are the data-quality columns that I check when returning records.
#
# If one of these flags is set on a record, I include it as a caveat so
# that the assistant knows there may be an issue with the data.
# ---------------------------------------------------------------------------

SENSITIVE_FLAG_COLUMNS = [
    "Duration_Mismatch",
    "Downtime_Mismatch",
    "Meter_Reading_Outlier",
    "Value_Negative_Implausible",
    "Value_Likely_Sentinel",
    "Unit_Mismatch",
    "Hours_Outlier",
    "Availability_Pct_Invalid",
    "Utilisation_Pct_Invalid",
    "Loads_Negative",
    "Fuel_Zero_While_Working",
    "Priority_Inconsistent_Scale",
    "Closed_Before_Observed",
    "Open_With_Closed_Date",
    "Severity_Description_Contradiction",
    "Date_Pair_Unresolved",
    "Score_Out_Of_Range",
    "Result_Score_Mismatch",
    "Duration_Negative",
    "Quantity_Outlier",
    "Event_Time_Anomaly",
    "Reading_Time_Anomaly",
    "Employee_Identity_Mismatch",
]


# ---------------------------------------------------------------------------
# Helper functions.
#
# I use these functions to avoid repeating the same loading, masking and
# data-quality logic in every individual tool.
# ---------------------------------------------------------------------------

def _load(name: str) -> pd.DataFrame:
    """
    Load one of the cleaned datasets.

    I return an empty DataFrame if the file does not exist so that the
    tool can handle the problem without crashing the whole application.
    """

    path = os.path.join(
        DATA_DIR,
        f"{name}_cleaned.csv",
    )

    if not os.path.exists(path):

        return pd.DataFrame()

    return pd.read_csv(
        path
    )


def _mask_pii(
    df: pd.DataFrame
) -> pd.DataFrame:
    """
    Mask any columns that could directly identify a person.

    I make a copy first so that I don't accidentally change the original
    DataFrame that was loaded from the dataset.
    """

    df = df.copy()

    for col in PII_COLUMNS:

        if col in df.columns:

            df[col] = "[masked]"

    return df


def _caveats_from_flags(
    df: pd.DataFrame
) -> list[str]:
    """
    Look through the returned records for known data-quality flags.

    If a flag is present, I count how many records have it and turn that
    into a short message that can be shown with the result.
    """

    caveats = []

    for col in SENSITIVE_FLAG_COLUMNS:

        if col in df.columns:

            n = int(
                df[col]
                .fillna(False)
                .astype(bool)
                .sum()
            )

            if n > 0:

                # I make the column name easier to read in the message.

                pretty = col.replace(
                    "_",
                    " ",
                )

                caveats.append(
                    f"{n} of these records have "
                    f"{pretty} = True"
                )

    return caveats


def _result(
    df: pd.DataFrame,
    id_col: str,
    note_if_empty: str,
) -> dict:
    """
    Convert the DataFrame into the same result format used by all the
    tools.

    I keep the format consistent because llm_client.py needs to handle
    results from different datasets in the same way.
    """

    if df.empty:

        return {
            "records": [],
            "record_ids": [],
            "caveats": [],
            "note": note_if_empty,
        }

    # I check the flags before masking the data so I can still inspect
    # the original values and identify any data-quality issues.

    caveats = _caveats_from_flags(
        df
    )

    # I mask identity-related fields before the records leave this file.

    df = _mask_pii(
        df
    )

    records = df.to_dict(
        orient="records"
    )

    # I collect the record IDs separately because they are useful when
    # checking the evidence behind an answer.

    ids = (
        df[id_col]
        .astype(str)
        .tolist()
        if id_col in df.columns
        else []
    )

    return {
        "records": records,
        "record_ids": ids,
        "caveats": caveats,
        "note": "",
    }


# ---------------------------------------------------------------------------
# Tool functions.
#
# These are the functions that the LLM is actually allowed to use.
# I keep the data access inside these functions instead of allowing the
# model to work with the datasets directly.
# ---------------------------------------------------------------------------

def get_downtime_by_equipment(
    equipment_name: str | None = None,
    top_n: int = 5,
) -> dict:
    """
    Get total delay or downtime information for equipment.

    I can either return records for a specific equipment asset or rank
    the equipment by total downtime when no asset is provided.
    """

    df = _load(
        "delays_downtime"
    )

    if df.empty:

        return _result(
            df,
            "Delay_ID",
            "No delay/downtime data available.",
        )

    minutes_col = (
        "Duration_Provided_Minutes"
    )

    working = df.copy()

    # If the user gives an equipment name, I filter the dataset first.

    if equipment_name:

        working = working[
            working[
                "Equipment_Name_Clean"
            ].str.contains(
                equipment_name,
                case=False,
                na=False,
            )
        ]

        if working.empty:

            return _result(
                working,
                "Delay_ID",
                f"No downtime records found for "
                f"'{equipment_name}'.",
            )

        return _result(
            working,
            "Delay_ID",
            "",
        )

    # If no specific equipment was requested, I calculate the total
    # downtime for each equipment and keep the top results.

    summary = (
        working
        .groupby(
            "Equipment_Name_Clean"
        )[minutes_col]
        .sum()
        .sort_values(
            ascending=False
        )
        .head(
            top_n
        )
    )

    # I then keep the detailed records belonging to those top assets
    # so that the answer can still be traced back to individual records.

    detail = working[
        working[
            "Equipment_Name_Clean"
        ].isin(
            summary.index
        )
    ]

    out = _result(
        detail,
        "Delay_ID",
        "",
    )

    # I add the calculated totals separately from the individual records.

    out[
        "summary_totals_minutes"
    ] = summary.round(
        1
    ).to_dict()

    return out


def get_safety_observations(
    severity: str | None = None,
    status: str | None = None,
    equipment_name: str | None = None,
) -> dict:
    """
    Return safety observation records.

    I allow the user to filter the results by severity, status, or
    equipment depending on what they are asking about.
    """

    df = _load(
        "safety_observations"
    )

    if df.empty:

        return _result(
            df,
            "Observation_ID",
            "No safety observation data available.",
        )

    working = df.copy()

    # Filter by severity if the user provided one.

    if severity:

        working = working[
            working[
                "Severity_Clean"
            ].str.lower()
            == severity.lower()
        ]

    # Filter by status if the user provided one.

    if status:

        working = working[
            working[
                "Status"
            ].str.lower()
            == status.lower()
        ]

    # Filter by equipment if the question is about a specific asset.

    if equipment_name:

        working = working[
            working[
                "Equipment_Name_Clean"
            ].str.contains(
                equipment_name,
                case=False,
                na=False,
            )
        ]

    note = (
        ""
        if not working.empty
        else "No safety observations matched those filters."
    )

    return _result(
        working,
        "Observation_ID",
        note,
    )


def get_training_expiry(
    operator_id: str | None = None,
    expiring_before: str | None = None,
) -> dict:
    """
    Return training and certification records.

    I can filter these records by operator ID or by an expiry date.
    """

    df = _load(
        "training_records"
    )

    if df.empty:

        return _result(
            df,
            "Training_Record_ID",
            "No training data available.",
        )

    working = df.copy()

    # If an operator ID is provided, I only return matching records.

    if operator_id:

        working = working[
            working[
                "Operator_ID"
            ].str.upper()
            == operator_id.upper()
        ]

    # If an expiry date is provided, I return records expiring on or
    # before that date.

    if expiring_before:

        working = working[
            working[
                "Expiry_Date_Clean"
            ].notna()
            &
            (
                working[
                    "Expiry_Date_Clean"
                ]
                <= expiring_before
            )
        ]

    note = (
        ""
        if not working.empty
        else "No training records matched those filters."
    )

    return _result(
        working,
        "Training_Record_ID",
        note,
    )


def get_equipment_status(
    equipment_name: str | None = None,
) -> dict:
    """
    Return equipment event records.

    I sort the results by the cleaned event time so that the most recent
    events appear first.
    """

    df = _load(
        "equipment_events"
    )

    if df.empty:

        return _result(
            df,
            "Event_ID",
            "No equipment event data available.",
        )

    working = df.copy()

    # If a specific equipment asset was mentioned, I filter to it.

    if equipment_name:

        working = working[
            working[
                "Equipment_Name_Clean"
            ].str.contains(
                equipment_name,
                case=False,
                na=False,
            )
        ]

    # I sort by event time so the newest events are easier to see.

    working = working.sort_values(
        "Event_Time_Clean",
        ascending=False,
    )

    note = (
        ""
        if not working.empty
        else (
            f"No equipment events found for "
            f"'{equipment_name}'."
        )
    )

    return _result(
        working,
        "Event_ID",
        note,
    )


def get_maintenance_notifications(
    equipment_name: str | None = None,
    priority: str | None = None,
) -> dict:
    """
    Return maintenance notification records.

    I can filter the results by equipment or by the priority of the
    maintenance notification.
    """

    df = _load(
        "maintenance_notifications"
    )

    if df.empty:

        return _result(
            df,
            "Notification_ID",
            "No maintenance data available.",
        )

    working = df.copy()

    # Filter by equipment when required.

    if equipment_name:

        working = working[
            working[
                "Equipment_Name_Clean"
            ].str.contains(
                equipment_name,
                case=False,
                na=False,
            )
        ]

    # Filter by priority when required.

    if priority:

        working = working[
            working[
                "Priority"
            ].str.upper()
            == priority.upper()
        ]

    note = (
        ""
        if not working.empty
        else (
            "No maintenance notifications matched "
            "those filters."
        )
    )

    return _result(
        working,
        "Notification_ID",
        note,
    )


def get_shift_performance(
    equipment_name: str | None = None,
    crew: str | None = None,
) -> dict:
    """
    Return shift performance information.

    I can filter the results using either equipment or crew.
    """

    df = _load(
        "shift_performance"
    )

    if df.empty:

        return _result(
            df,
            "Shift_Record_ID",
            "No shift performance data available.",
        )

    working = df.copy()

    # Filter the records to a specific equipment asset if needed.

    if equipment_name:

        working = working[
            working[
                "Equipment_Name_Clean"
            ].str.contains(
                equipment_name,
                case=False,
                na=False,
            )
        ]

    # Filter by crew if the question is about a particular crew.

    if crew:

        working = working[
            working[
                "Crew"
            ].str.lower()
            == crew.lower()
        ]

    note = (
        ""
        if not working.empty
        else (
            "No shift performance records matched "
            "those filters."
        )
    )

    return _result(
        working,
        "Shift_Record_ID",
        note,
    )


def get_data_quality_summary(
    dataset: str | None = None,
) -> dict:
    """
    Return the number of data-quality exceptions for each dataset.

    I get this information from the exception report created during
    Task 1 instead of recalculating all the checks here.
    """

    path = os.path.join(
        DATA_DIR,
        "exception_report.csv",
    )

    if not os.path.exists(path):

        return {
            "records": [],
            "record_ids": [],
            "caveats": [],
            "note": "No exception report available.",
        }

    df = pd.read_csv(
        path
    )

    # If the user asks about one dataset, I filter the exception report
    # before calculating the summary.

    if dataset:

        df = df[
            df[
                "Dataset"
            ].str.contains(
                dataset,
                case=False,
                na=False,
            )
        ]

    if df.empty:

        return {
            "records": [],
            "record_ids": [],
            "caveats": [],
            "note": (
                f"No exceptions found for "
                f"'{dataset}'."
                if dataset
                else "No exceptions on file."
            ),
        }

    # Count how many exception records belong to each dataset.

    summary = (
        df.groupby(
            "Dataset"
        )
        .size()
        .to_dict()
    )

    return {
        "records": df.to_dict(
            orient="records"
        ),
        "record_ids": df[
            "Record_ID"
        ].astype(str).tolist(),
        "caveats": [],
        "note": "",
        "summary_counts": summary,
    }


# ---------------------------------------------------------------------------
# Tool registry.
#
# This is basically the allow-list for the LLM. If a function is not added
# here, llm_client.py cannot call it through the tool-calling process.
# ---------------------------------------------------------------------------

TOOL_REGISTRY = {
    "get_downtime_by_equipment": get_downtime_by_equipment,
    "get_safety_observations": get_safety_observations,
    "get_training_expiry": get_training_expiry,
    "get_equipment_status": get_equipment_status,
    "get_maintenance_notifications": get_maintenance_notifications,
    "get_shift_performance": get_shift_performance,
    "get_data_quality_summary": get_data_quality_summary,
}
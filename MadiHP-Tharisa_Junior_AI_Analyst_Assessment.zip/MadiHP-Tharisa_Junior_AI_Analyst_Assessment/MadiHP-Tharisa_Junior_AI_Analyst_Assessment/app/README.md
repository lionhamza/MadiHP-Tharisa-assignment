# app/

This folder contains the applications I built for Task 2 and Task 3.

## Task 2 — Data-Quality Triage App

For Task 2, I built two versions of the data-quality triage app. Both versions can check a CSV file for:

* Missing values
* Duplicate rows
* Date issues
* Outliers
* Data-quality score
* Suggested corrections
* Exception records that can be downloaded

### `triage_app/`

This is the HTML and JavaScript version of my app.

I can open the `index.html` file directly in a browser. It does not need to be installed and can work offline.

### `triage_app_streamlit/`

This is the Streamlit version that I built using Python and pandas.

To run it:

```bash
pip install -r requirements.txt
streamlit run app.py
```

The main analysis is in `analysis.py`, while `app.py` is used for the interface.

Both versions do the same type of analysis, so I will only submit one of them for Task 2.

## Task 3 — Operational Knowledge Assistant


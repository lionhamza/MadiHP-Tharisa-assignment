"""
Data-Quality Triage App

Run the app with:

    streamlit run app.py

Upload a CSV file and the app checks for:
- Missing values
- Duplicate rows and IDs
- Invalid or mixed date formats
- Numeric outliers
- Inconsistent category labels

It also gives the dataset a quality score and allows the user
to download a file containing all detected issues.
"""

import pandas as pd
import streamlit as st
import analysis


# Page setup
st.set_page_config(
    page_title="Data Quality Triage",
    layout="wide"
)

st.title("Data-Quality Triage App")

st.write(
    "Upload a CSV file to check for common data-quality problems such as "
    "missing values, duplicates, invalid dates, outliers, and inconsistent labels."
)


# File upload
uploaded_file = st.file_uploader(
    "Choose a CSV file",
    type="csv"
)


if uploaded_file is None:
    st.info("Please upload a CSV file to begin.")
    st.stop()


# Load the CSV
try:
    # Read everything as text first so IDs such as 007 are not changed
    # and dates are not automatically converted by pandas.
    df = pd.read_csv(
        uploaded_file,
        dtype=str,
        keep_default_na=False
    )

except Exception as error:
    st.error(f"Could not read the file: {error}")
    st.stop()


# Check if the file contains data
if df.empty:
    st.warning("The uploaded file does not contain any data rows.")
    st.stop()


# Run the analysis
with st.spinner("Checking data quality..."):
    results = analysis.run_full_analysis(df)


st.caption(
    f"File: {uploaded_file.name} | "
    f"{results['n_rows']} rows | "
    f"{results['n_cols']} columns"
)


# ============================================================
# DATA QUALITY SCORE
# ============================================================

st.header("Data-Quality Score")

scores = results["scores"]

col1, col2, col3, col4, col5 = st.columns(5)

col1.metric("Overall", f"{scores['overall']:.0f}")
col2.metric("Completeness", f"{scores['completeness']:.0f}")
col3.metric("Uniqueness", f"{scores['uniqueness']:.0f}")
col4.metric("Validity", f"{scores['validity']:.0f}")
col5.metric("Consistency", f"{scores['consistency']:.0f}")


# Simple explanation of the overall score
if scores["overall"] >= 85:
    st.success(
        "The dataset looks good overall. Only the flagged records should be reviewed."
    )

elif scores["overall"] >= 65:
    st.warning(
        "The dataset can be used, but the flagged records should be reviewed first."
    )

else:
    st.error(
        "The dataset has several quality issues and should be reviewed before analysis."
    )


# Show how the score works
with st.expander("How is the score calculated?"):
    st.markdown("""
    - **Completeness** checks for missing values.
    - **Uniqueness** checks for duplicate rows.
    - **Validity** checks date formats and unusual numeric values.
    - **Consistency** checks for different spellings of similar category values.
    - **Overall** is the average of these scores.

    The score is only used as a guide. It does not automatically decide
    whether the dataset is good or bad.
    """)


# ============================================================
# MISSING VALUES
# ============================================================

st.header("Missing Values")

missing_data = results["missing_df"]

missing_data = missing_data[
    missing_data["missing_count"] > 0
].sort_values(
    "missing_count",
    ascending=False
)


if not missing_data.empty:
    st.dataframe(
        missing_data,
        use_container_width=True,
        hide_index=True
    )
else:
    st.success("No missing values were found.")


# ============================================================
# DUPLICATES
# ============================================================

st.header("Duplicate Detection")

duplicate_info = results["dup_info"]


# Exact duplicate rows
if duplicate_info["exact_duplicate_rows"]:

    duplicate_rows = duplicate_info["exact_duplicate_rows"]

    st.warning(
        f"{len(duplicate_rows)} duplicate row(s) were found."
    )

    st.write(
        "Rows:",
        ", ".join(str(row) for row in duplicate_rows[:40])
    )

else:
    st.success("No exact duplicate rows were found.")


# Duplicate IDs
if duplicate_info["id_column"]:

    id_column = duplicate_info["id_column"]

    if duplicate_info["duplicate_key_rows"]:

        st.warning(
            f"Duplicate values were found in the ID column: {id_column}"
        )

        duplicate_ids = pd.DataFrame(
            duplicate_info["duplicate_key_rows"]
        )

        st.dataframe(
            duplicate_ids,
            use_container_width=True,
            hide_index=True
        )

    else:
        st.success(
            f"No duplicate values were found in {id_column}."
        )

else:
    st.info(
        "No ID column was detected for checking duplicate record IDs."
    )


# ============================================================
# DATE VALIDITY
# ============================================================

st.header("Date and Time Checks")

date_results = results["date_report"]


if not date_results:

    st.info("No date or time columns were detected.")

else:

    for date_info in date_results:

        column_name = date_info["column"]
        checked = date_info["checked"]
        invalid = date_info["invalid"]

        st.subheader(column_name)

        st.write(
            f"Values checked: {checked} | Invalid values: {invalid}"
        )


        # Show detected formats
        if date_info["formats_seen"]:

            format_text = []

            for date_format, count in date_info["formats_seen"]:
                format_text.append(
                    f"{date_format} ({count})"
                )

            st.caption(
                "Formats found: " + ", ".join(format_text)
            )


        # Show invalid values
        if date_info["bad_rows"]:

            st.warning(
                f"{invalid} invalid date value(s) were found."
            )

            bad_dates = pd.DataFrame(
                date_info["bad_rows"]
            )

            st.dataframe(
                bad_dates,
                use_container_width=True,
                hide_index=True
            )


    # Check if different formats are being used
    mixed_formats = any(
        len(item["formats_seen"]) > 1
        for item in date_results
    )

    if mixed_formats:

        st.info(
            "Some columns contain more than one date format. "
            "These values should be checked before combining or analysing the data."
        )


# ============================================================
# NUMERIC OUTLIERS
# ============================================================

st.header("Numeric Outlier Checks")

outlier_results = results["outlier_report"]


if not outlier_results:

    st.info(
        "No numeric columns contained enough values for outlier analysis."
    )

else:

    for outlier_info in outlier_results:

        column_name = outlier_info["column"]
        low = outlier_info["low_fence"]
        high = outlier_info["high_fence"]

        outlier_count = len(
            outlier_info["outliers"]
        )

        negative_count = len(
            outlier_info["negatives"]
        )


        st.subheader(column_name)

        st.write(
            f"Expected range: {low:.1f} to {high:.1f}"
        )

        st.write(
            f"Outliers found: {outlier_count}"
        )

        st.write(
            f"Unexpected negative values: {negative_count}"
        )


        # Combine outliers and negative values
        flagged_values = (
            outlier_info["outliers"]
            + outlier_info["negatives"]
        )

        if flagged_values:

            flagged_df = pd.DataFrame(
                flagged_values
            )

            st.dataframe(
                flagged_df,
                use_container_width=True,
                hide_index=True
            )


    st.caption(
        "Outliers are detected using the IQR method. "
        "They are warnings for review and are not automatically removed."
    )


# ============================================================
# CATEGORY AND LABEL CONSISTENCY
# ============================================================

st.header("Category and Label Consistency")

label_results = results["label_report"]


if not label_results:

    st.info(
        "No inconsistent category labels were detected."
    )

else:

    for label_info in label_results:

        st.subheader(
            label_info["column"]
        )

        for group in label_info["groups"]:

            canonical = group["canonical"]

            variants = []

            for value, count in group["variants"]:

                variants.append(
                    f"{value} ({count})"
                )

            st.write(
                f"Main value: {canonical}"
            )

            st.caption(
                "Different versions found: "
                + ", ".join(variants)
            )


# ============================================================
# SUGGESTED CORRECTIONS
# ============================================================

st.header("Suggested Corrections")

suggestions = results["suggestions"]


if suggestions:

    for suggestion in suggestions:

        column = suggestion["column"]
        message = suggestion["text"]
        severity = suggestion["severity"]

        if severity == "high":

            st.warning(
                f"**{column}** — {message}"
            )

        else:

            st.info(
                f"**{column}** — {message}"
            )

else:

    st.success(
        "No corrections were suggested."
    )


# ============================================================
# EXCEPTION FILE
# ============================================================

st.header("Exception File")

exceptions = results["exceptions_df"]

st.write(
    f"{len(exceptions)} issue(s) were found in the dataset."
)

st.caption(
    "A row can appear more than once if it has more than one data-quality issue."
)


# Download button
st.download_button(
    label="Download Exception File",
    data=exceptions.to_csv(
        index=False
    ).encode("utf-8"),
    file_name=(
        uploaded_file.name.rsplit(".", 1)[0]
        + "_exceptions.csv"
    ),
    mime="text/csv"
)


# Show exception data
if not exceptions.empty:

    st.dataframe(
        exceptions,
        use_container_width=True,
        hide_index=True
    )

else:

    st.success(
        "No exceptions were found."
    )
"""
Data Quality Triage App
Core analysis functions used by the Streamlit app.
"""

import re
import pandas as pd


# Values that will be treated as missing
MISSING_VALUES = {
    "", "na", "n/a", "null", "none",
    "nan", "-", "--", "?"
}


# --------------------------------------------------
# Missing values
# --------------------------------------------------

def is_missing(value):
    """Check if a value should be treated as missing."""

    if pd.isna(value):
        return True

    value = str(value).strip().lower()

    return value in MISSING_VALUES


def check_missing_values(df):
    """Count missing values in each column."""

    results = []
    total_rows = len(df)

    for column in df.columns:

        missing = df[column].apply(is_missing)
        missing_count = missing.sum()

        if total_rows > 0:
            missing_percent = round(
                (missing_count / total_rows) * 100,
                1
            )
        else:
            missing_percent = 0

        results.append({
            "column": column,
            "missing_count": int(missing_count),
            "missing_pct": missing_percent
        })

    return pd.DataFrame(results)


# --------------------------------------------------
# Duplicate checks
# --------------------------------------------------

def check_duplicates(df):
    """Check for duplicate rows and repeated IDs."""

    duplicate_mask = df.duplicated(keep=False)

    duplicate_rows = []

    for index in df.index[duplicate_mask]:
        # +2 because row 1 is normally the CSV header
        duplicate_rows.append(index + 2)

    # Try to find a column that looks like an ID
    id_column = None

    for column in df.columns:
        if re.search(r"(^|_)id$", column, re.IGNORECASE):
            id_column = column
            break

    duplicate_ids = []

    if id_column is not None:

        valid_rows = df[
            ~df[id_column].apply(is_missing)
        ]

        counts = valid_rows[id_column].value_counts()

        repeated_values = counts[
            counts > 1
        ].index

        for index, value in valid_rows[id_column].items():

            if value in repeated_values:
                duplicate_ids.append({
                    "row": index + 2,
                    "id": value
                })

    return {
        "exact_duplicate_rows": sorted(
            list(set(duplicate_rows))
        ),
        "id_column": id_column,
        "duplicate_key_rows": duplicate_ids
    }


# --------------------------------------------------
# Date checks
# --------------------------------------------------

DATE_PATTERNS = [

    (
        re.compile(
            r"^\d{4}-\d{1,2}-\d{1,2}"
            r"([ T]\d{1,2}:\d{2}(:\d{2})?)?$"
        ),
        "ISO (YYYY-MM-DD)"
    ),

    (
        re.compile(
            r"^\d{4}/\d{1,2}/\d{1,2}"
            r"([ T]\d{1,2}:\d{2})?$"
        ),
        "YYYY/MM/DD"
    ),

    (
        re.compile(
            r"^\d{1,2}/\d{1,2}/\d{4} "
            r"\d{1,2}:\d{2} ?(AM|PM)$",
            re.IGNORECASE
        ),
        "M/D/Y (12hr)"
    ),

    (
        re.compile(
            r"^\d{1,2}/\d{1,2}/\d{4}"
            r"( \d{1,2}:\d{2})?$"
        ),
        "D/M/Y or M/D/Y"
    ),

    (
        re.compile(r"^\d{1,2}-\d{1,2}-\d{4}$"),
        "D-M-Y"
    )
]


DATE_NAME_PATTERN = re.compile(
    r"date|time|_at$|_dt$|timestamp",
    re.IGNORECASE
)


def get_date_format(value):
    """Return the date format if one is recognised."""

    value = str(value).strip()

    for pattern, name in DATE_PATTERNS:

        if pattern.match(value):
            return name

    return None


def is_date_column(column_name, values):
    """Try to determine if a column contains dates."""

    # First check the column name
    if DATE_NAME_PATTERN.search(column_name):
        return True

    # Check a small sample of values
    valid_values = values[
        ~values.apply(is_missing)
    ].head(30)

    if len(valid_values) == 0:
        return False

    matches = 0

    for value in valid_values:

        if get_date_format(value) is not None:
            matches += 1

    return matches / len(valid_values) > 0.5


def check_dates(df):
    """Check date columns for invalid and mixed formats."""

    results = []

    for column in df.columns:

        values = df[column]

        if not is_date_column(column, values):
            continue

        non_missing = values[
            ~values.apply(is_missing)
        ]

        formats = {}
        bad_rows = []

        for index, value in non_missing.items():

            date_format = get_date_format(value)

            if date_format:

                if date_format not in formats:
                    formats[date_format] = 0

                formats[date_format] += 1

            else:

                bad_rows.append({
                    "row": index + 2,
                    "value": value
                })

        sorted_formats = sorted(
            formats.items(),
            key=lambda item: item[1],
            reverse=True
        )

        results.append({
            "column": column,
            "checked": len(non_missing),
            "invalid": len(bad_rows),
            "formats_seen": sorted_formats,
            "bad_rows": bad_rows
        })

    return results


# --------------------------------------------------
# Numeric values and outliers
# --------------------------------------------------

def convert_to_number(value):
    """Try to convert a value to a number."""

    if is_missing(value):
        return None

    value = str(value).replace(",", "").strip()

    try:
        return float(value)

    except ValueError:
        return None


def is_numeric_column(values):
    """Check whether most values in a column are numeric."""

    non_missing = values[
        ~values.apply(is_missing)
    ]

    if len(non_missing) == 0:
        return False

    numeric_count = 0

    for value in non_missing:

        if convert_to_number(value) is not None:
            numeric_count += 1

    return numeric_count / len(non_missing) > 0.85


def check_outliers(df):
    """Find possible numeric outliers using the IQR method."""

    results = []

    for column in df.columns:

        values = df[column]

        if not is_numeric_column(values):
            continue

        numbers = values.apply(convert_to_number)

        valid_numbers = numbers.dropna()

        if len(valid_numbers) < 4:
            continue

        q1 = valid_numbers.quantile(0.25)
        q3 = valid_numbers.quantile(0.75)

        iqr = q3 - q1

        lower_limit = q1 - (1.5 * iqr)
        upper_limit = q3 + (1.5 * iqr)

        outlier_mask = (
            (numbers < lower_limit) |
            (numbers > upper_limit)
        )

        outliers = []

        for index, value in numbers[outlier_mask].items():

            outliers.append({
                "row": index + 2,
                "value": value
            })

        # Check negative values.
        # Only flag them if negative values are unusual
        negative_values = numbers[numbers < 0]

        negative_percentage = 0

        if len(valid_numbers) > 0:
            negative_percentage = (
                len(negative_values) / len(valid_numbers)
            )

        negatives = []

        if 0 < negative_percentage < 0.1:

            for index, value in negative_values.items():

                negatives.append({
                    "row": index + 2,
                    "value": value
                })

        results.append({
            "column": column,
            "n": int(len(valid_numbers)),
            "low_fence": float(lower_limit),
            "high_fence": float(upper_limit),
            "outliers": outliers,
            "negatives": negatives
        })

    return results


# --------------------------------------------------
# Label consistency
# --------------------------------------------------

def clean_label(value):
    """Remove spaces and special characters for comparison."""

    value = str(value).lower()

    return re.sub(
        r"[^a-z0-9]",
        "",
        value
    )


def check_labels(df, date_columns, numeric_columns):
    """Look for different spellings of the same category."""

    results = []

    for column in df.columns:

        if column in date_columns:
            continue

        if column in numeric_columns:
            continue

        values = df[column]

        non_missing = values[
            ~values.apply(is_missing)
        ]

        if len(non_missing) == 0:
            continue

        unique_values = non_missing.unique()

        # Only check columns that look like categories
        if len(unique_values) < 2 or len(unique_values) > 40:
            continue

        groups = {}

        for value in non_missing:

            normal_value = clean_label(value)

            if normal_value not in groups:
                groups[normal_value] = {}

            if value not in groups[normal_value]:
                groups[normal_value][value] = 0

            groups[normal_value][value] += 1

        inconsistent_groups = []

        for normal_value, variants in groups.items():

            if len(variants) <= 1:
                continue

            sorted_variants = sorted(
                variants.items(),
                key=lambda item: item[1],
                reverse=True
            )

            inconsistent_groups.append({
                "canonical": sorted_variants[0][0],
                "variants": sorted_variants
            })

        if inconsistent_groups:

            results.append({
                "column": column,
                "groups": inconsistent_groups
            })

    return results


# --------------------------------------------------
# Data quality score
# --------------------------------------------------

def calculate_score(
    df,
    missing_df,
    duplicate_info,
    date_report,
    outlier_report,
    label_report
):
    """Calculate the main data quality scores."""

    rows, columns = df.shape
    total_cells = rows * columns

    # Completeness
    total_missing = missing_df["missing_count"].sum()

    if total_cells > 0:
        completeness = (
            100 * (1 - total_missing / total_cells)
        )
    else:
        completeness = 100

    # Uniqueness
    duplicate_count = len(
        duplicate_info["exact_duplicate_rows"]
    )

    if rows > 0:
        uniqueness = (
            100 * (1 - duplicate_count / rows)
        )
    else:
        uniqueness = 100

    # Date validity
    checked_dates = sum(
        item["checked"]
        for item in date_report
    )

    invalid_dates = sum(
        item["invalid"]
        for item in date_report
    )

    if checked_dates > 0:
        date_score = (
            100 * (1 - invalid_dates / checked_dates)
        )
    else:
        date_score = 100

    # Outlier score
    outlier_flags = 0

    for item in outlier_report:

        outlier_flags += len(item["outliers"])
        outlier_flags += len(item["negatives"])

    if len(outlier_report) > 0 and rows > 0:

        possible_checks = (
            len(outlier_report) * rows
        )

        outlier_rate = (
            outlier_flags / possible_checks
        )

        outlier_score = (
            100 * (1 - min(outlier_rate * 4, 1))
        )

    else:
        outlier_score = 100

    validity = (
        date_score + outlier_score
    ) / 2

    # Consistency
    label_issues = 0

    for column in label_report:

        for group in column["groups"]:

            count = sum(
                item[1]
                for item in group["variants"]
            )

            label_issues += count - 1

    date_columns = {
        item["column"]
        for item in date_report
    }

    numeric_columns = {
        item["column"]
        for item in outlier_report
    }

    category_columns = (
        columns -
        len(date_columns) -
        len(numeric_columns)
    )

    category_cells = (
        category_columns * rows
    )

    if category_cells > 0:

        consistency = (
            100 * (
                1 - label_issues / category_cells
            )
        )

    else:
        consistency = 100

    overall = (
        completeness +
        uniqueness +
        validity +
        consistency
    ) / 4

    # Keep values between 0 and 100
    def limit(value):
        return max(0, min(100, value))

    return {
        "completeness": limit(completeness),
        "uniqueness": limit(uniqueness),
        "validity": limit(validity),
        "consistency": limit(consistency),
        "overall": limit(overall)
    }


# --------------------------------------------------
# Suggestions
# --------------------------------------------------

def get_suggestions(
    missing_df,
    duplicate_info,
    date_report,
    outlier_report,
    label_report
):
    """Create simple suggestions based on the issues found."""

    suggestions = []

    # Missing values
    for _, row in missing_df.iterrows():

        if row["missing_count"] == 0:
            continue

        if row["missing_pct"] > 30:

            message = (
                f"{row['missing_pct']}% of the values are missing. "
                "There may not be enough information to fill them in "
                "reliably, so these values should be reviewed first."
            )

            severity = "high"

        else:

            message = (
                f"{row['missing_count']} value(s) are missing "
                f"({row['missing_pct']}%). Check what a blank value "
                "means before replacing it."
            )

            severity = "low"

        suggestions.append({
            "column": row["column"],
            "severity": severity,
            "text": message
        })

    # Exact duplicates
    if duplicate_info["exact_duplicate_rows"]:

        count = len(
            duplicate_info["exact_duplicate_rows"]
        )

        suggestions.append({
            "column": "(all columns)",
            "severity": "high",
            "text": (
                f"{count} duplicate row(s) were found. "
                "Check them before removing them to make sure they "
                "are not genuine repeated records."
            )
        })

    # Duplicate IDs
    if duplicate_info["duplicate_key_rows"]:

        count = len(
            duplicate_info["duplicate_key_rows"]
        )

        suggestions.append({
            "column": duplicate_info["id_column"],
            "severity": "high",
            "text": (
                f"The ID column has repeated values on {count} row(s). "
                "The original source should be checked because IDs "
                "are normally expected to be unique."
            )
        })

    # Dates
    for item in date_report:

        if item["invalid"] > 0:

            suggestions.append({
                "column": item["column"],
                "severity": "high",
                "text": (
                    f"{item['invalid']} value(s) do not match the "
                    "recognised date formats and should be checked "
                    "before using them for time-based analysis."
                )
            })

        if len(item["formats_seen"]) > 1:

            suggestions.append({
                "column": item["column"],
                "severity": "low",
                "text": (
                    f"This column contains {len(item['formats_seen'])} "
                    "different date formats. It would be better to "
                    "standardise the dates before analysis."
                )
            })

    # Outliers and negative values
    for item in outlier_report:

        if item["negatives"]:

            suggestions.append({
                "column": item["column"],
                "severity": "high",
                "text": (
                    f"{len(item['negatives'])} unexpected negative "
                    "value(s) were found. Check for possible sign "
                    "or unit errors."
                )
            })

        if item["outliers"]:

            suggestions.append({
                "column": item["column"],
                "severity": "low",
                "text": (
                    f"{len(item['outliers'])} possible outlier(s) "
                    "were found. These should be reviewed before "
                    "deciding whether they are actual errors."
                )
            })

    # Inconsistent labels
    for column in label_report:

        variant_count = sum(
            len(group["variants"])
            for group in column["groups"]
        )

        suggestions.append({
            "column": column["column"],
            "severity": "low",
            "text": (
                f"{variant_count} different label variations were "
                "found. Consider standardising the values before "
                "using them for grouping or reporting."
            )
        })

    return suggestions


# --------------------------------------------------
# Build exception file
# --------------------------------------------------

def build_exception_file(
    df,
    missing_df,
    duplicate_info,
    date_report,
    outlier_report,
    label_report
):
    """Create a DataFrame containing all detected issues."""

    exceptions = []

    # Missing values
    for column in df.columns:

        missing_mask = df[column].apply(is_missing)

        for index in df.index[missing_mask]:

            exceptions.append({
                "row": index + 2,
                "column": column,
                "issue": "Missing value",
                "value": "",
                "detail": "Blank or missing value"
            })

    # Exact duplicates
    for row in duplicate_info["exact_duplicate_rows"]:

        exceptions.append({
            "row": row,
            "column": "(all columns)",
            "issue": "Exact duplicate row",
            "value": "",
            "detail": "Matches another row in the file"
        })

    # Duplicate IDs
    if duplicate_info["id_column"]:

        for item in duplicate_info["duplicate_key_rows"]:

            exceptions.append({
                "row": item["row"],
                "column": duplicate_info["id_column"],
                "issue": "Duplicate key",
                "value": item["id"],
                "detail": "This ID appears more than once"
            })

    # Invalid dates
    for item in date_report:

        for bad_row in item["bad_rows"]:

            exceptions.append({
                "row": bad_row["row"],
                "column": item["column"],
                "issue": "Invalid date/time",
                "value": bad_row["value"],
                "detail": "Date format was not recognised"
            })

    # Outliers
    for item in outlier_report:

        for outlier in item["outliers"]:

            exceptions.append({
                "row": outlier["row"],
                "column": item["column"],
                "issue": "Possible outlier",
                "value": outlier["value"],
                "detail": (
                    f"Outside the IQR range "
                    f"[{item['low_fence']:.2f}, "
                    f"{item['high_fence']:.2f}]"
                )
            })

        for negative in item["negatives"]:

            exceptions.append({
                "row": negative["row"],
                "column": item["column"],
                "issue": "Negative value",
                "value": negative["value"],
                "detail": "Check whether the negative value is valid"
            })

    # Inconsistent labels
    for column in label_report:

        for group in column["groups"]:

            canonical = group["canonical"]

            for variant, count in group["variants"]:

                if variant == canonical:
                    continue

                mask = (
                    df[column["column"]] == variant
                )

                for index in df.index[mask]:

                    exceptions.append({
                        "row": index + 2,
                        "column": column["column"],
                        "issue": "Inconsistent label",
                        "value": variant,
                        "detail": (
                            f"Possible variation of "
                            f"'{canonical}'"
                        )
                    })

    exception_df = pd.DataFrame(
        exceptions,
        columns=[
            "row",
            "column",
            "issue",
            "value",
            "detail"
        ]
    )

    return (
        exception_df
        .sort_values("row", kind="stable")
        .reset_index(drop=True)
    )


# --------------------------------------------------
# Run all checks
# --------------------------------------------------

def run_full_analysis(df):
    """Run all data quality checks."""

    missing_df = check_missing_values(df)

    duplicate_info = check_duplicates(df)

    date_report = check_dates(df)

    outlier_report = check_outliers(df)

    date_columns = {
        item["column"]
        for item in date_report
    }

    numeric_columns = {
        item["column"]
        for item in outlier_report
    }

    label_report = check_labels(
        df,
        date_columns,
        numeric_columns
    )

    scores = calculate_score(
        df,
        missing_df,
        duplicate_info,
        date_report,
        outlier_report,
        label_report
    )

    suggestions = get_suggestions(
        missing_df,
        duplicate_info,
        date_report,
        outlier_report,
        label_report
    )

    exceptions_df = build_exception_file(
        df,
        missing_df,
        duplicate_info,
        date_report,
        outlier_report,
        label_report
    )

    return {
        "n_rows": len(df),
        "n_cols": df.shape[1],
        "missing_df": missing_df,
        "dup_info": duplicate_info,
        "date_report": date_report,
        "outlier_report": outlier_report,
        "label_report": label_report,
        "scores": scores,
        "suggestions": suggestions,
        "exceptions_df": exceptions_df
    }

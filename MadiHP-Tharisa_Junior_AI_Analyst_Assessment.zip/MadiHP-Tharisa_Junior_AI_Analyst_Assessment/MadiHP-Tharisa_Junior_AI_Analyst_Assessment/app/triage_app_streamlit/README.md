# Data-Quality Triage App — Streamlit Version (Task 2)

A small Streamlit application that I built for Task 2. Users can upload any CSV file and get a data-quality scorecard, missing-value analysis, duplicate detection, invalid-date detection, outlier warnings, suggested corrections, and a downloadable exception file.

## How to Run

```bash
pip install -r requirements.txt

streamlit run app.py
```

The application opens at `http://localhost:8501`.

I can upload any CSV file with a header row. I can also test it using the Project Signal datasets after exporting the Excel sheets to CSV.

## How to Host It

For the "share a link" submission option, I can host the application using Streamlit Community Cloud.

I can push the project to GitHub, connect the repository to Streamlit Community Cloud, select `app.py`, and deploy the application.

## Structure

* `analysis.py` — contains the main analysis logic, including missing values, duplicates, date-format detection, IQR outliers, label consistency, scoring, suggestions, and exception export.

* `app.py` — contains the Streamlit user interface and displays the results from `analysis.py`.

## Design Choices

* **Read data as strings.** I load CSV files using `dtype=str` so that IDs with leading zeros and ambiguous dates are not changed automatically before analysis.

* **Dates are flagged, not guessed.** If a column contains multiple date formats, the application reports the inconsistency instead of automatically choosing an interpretation.

* **Negative values are checked carefully.** Negative values are mainly flagged when they are unusual compared to the rest of the column.

* **Nothing is automatically corrected.** The application identifies and reports possible problems, but the final decision about fixing the data is left to the user.

## Known Limitations

* Date detection supports common formats but not every possible date format.

* ID or key columns are identified mainly by column names ending in `_id`. If a dataset uses a different naming style, this check may not run.

* Label consistency checks only run on columns with a reasonable number of unique values, so free-text columns are not incorrectly treated as categories.

* This is a general data-quality tool and does not understand the specific business meaning of every dataset. It cannot detect business-rule contradictions that require domain knowledge, such as checking whether a training certificate has the correct validity period.

For this reason, I see the application as a first-pass data-quality triage tool. More specific checks still need to be performed using dataset-specific rules, such as the cleaning scripts I created for Task 1.
